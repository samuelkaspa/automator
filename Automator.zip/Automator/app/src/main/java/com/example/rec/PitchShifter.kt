package com.example.rec

import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin

/**
 * Troca de tom em tempo real, sem mudar a velocidade da fala/áudio.
 * Duas leituras em atraso variável com crossfade (janela de Hann).
 * Custo muito baixo: com 0 semitons ([active] = false) nem é chamado.
 */
class PitchShifter(private val window: Int = 1920) {
    private val size = 4096
    private val mask = size - 1
    private val buf = FloatArray(size)
    private var w = 0
    private var phase = 0f
    private var step = 0f

    var semitones = 0
        set(v) {
            field = v.coerceIn(-12, 12)
            val ratio = 2.0.pow(field / 12.0)
            step = ((1.0 - ratio) / window).toFloat()
        }

    val active: Boolean get() = semitones != 0

    fun process(x: Float): Float {
        buf[w] = x
        val pa = phase
        var pb = pa + 0.5f
        if (pb >= 1f) pb -= 1f
        val ya = read(w - pa * window)
        val yb = read(w - pb * window)
        val ga = HANN[(pa * 1023f).toInt()]
        val out = ya * ga + yb * (1f - ga)
        w = (w + 1) and mask
        var np = pa + step
        if (np < 0f) np += 1f else if (np >= 1f) np -= 1f
        phase = np
        return out
    }

    private fun read(pos: Float): Float {
        val i = floor(pos).toInt()
        val f = pos - i
        val a = buf[i and mask]
        val b = buf[(i + 1) and mask]
        return a + (b - a) * f
    }

    companion object {
        private val HANN = FloatArray(1024) { k ->
            val s = sin(PI * k / 1023.0)
            (s * s).toFloat()
        }
    }
}
