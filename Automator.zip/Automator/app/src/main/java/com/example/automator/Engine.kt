package com.example.automator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.webkit.JavascriptInterface
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.luaj.vm2.Globals
import org.luaj.vm2.LuaValue
import org.luaj.vm2.lib.jse.CoerceJavaToLua
import org.luaj.vm2.lib.jse.JsePlatform
import org.mozilla.javascript.Context as JsCtx
import org.mozilla.javascript.ContextFactory
import org.mozilla.javascript.Function
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Erro especial (não é capturável por try/catch do script) usado para parar o script na hora. */
class StopErr : Error()

private class StopFactory(private val e: Engine) : ContextFactory() {
    override fun makeContext(): JsCtx {
        val c = super.makeContext()
        c.optimizationLevel = -1
        c.instructionObserverThreshold = 10000
        c.wrapFactory.setJavaPrimitiveWrap(false)
        return c
    }
    override fun observeInstructionCount(cx: JsCtx, instructionCount: Int) {
        while (e.paused && !e.stopped) Thread.sleep(50)
        if (e.stopped) throw StopErr()
    }
}

class Engine(private val ctx: Context, private val dir: File, private val lang: String = "JavaScript") {
    companion object {
        @Volatile var current: Engine? = null

        // nome:parâmetros  (a aridade tem que bater com os métodos de Api)
        private val spec = listOf(
            "click:x,y", "spam:x,y,ms", "stopSpam:", "swipe:a,b,c,d,ms", "hold:x,y,ms", "doubleClick:x,y",
            "pinch:x,y,f,t,ms", "scroll:d",
            "back:", "home:", "recents:", "notifications:", "quickSettings:", "powerMenu:", "lockScreen:", "screenshotKey:",
            "clickText:t", "waitText:t,ms", "screenText:", "typeText:t", "addText:t", "clearText:", "paste:",
            "currentApp:", "screenW:", "screenH:",
            "screenshot:n", "pixel:x,y", "findColor:h,tol",
            "openApp:n", "openUrl:u", "vibrate:ms", "toast:t", "flashlight:on", "battery:", "getVolume:", "setVolume:p",
            "getClipboard:", "setClipboard:t", "date:", "hour:", "minute:", "now:",
            "speak:t", "stopSpeak:", "listen:ms", "readScreen:", "ai:p", "askScreen:q", "setAiModel:m",
            "playAudio:n", "stopAudio:",
            "saveData:k,v", "loadData:k", "readFile:n", "writeFile:n,t", "deleteFile:n",
            "post:u,a,b", "httpGet:u,a",
            "setTouch:x,y", "blockTouch:", "delayTouch:ms", "touchX:", "touchY:", "touchKind:",
            "winShow:", "winHide:", "setWindow:x,y,w,h", "winFocus:on", "quit:"
        )
        // no HTML estas devolvem Promise (use await) para não travar a página
        private val asyncWeb = setOf("swipe", "hold", "doubleClick", "pinch", "scroll", "waitText", "screenshot", "pixel",
            "findColor", "listen", "ai", "askScreen", "post", "httpGet", "openApp")
        val apiNames: Set<String> = spec.map { it.substringBefore(":") }.toSet() +
            setOf("findTextJson", "findAllText", "files", "apps", "regCb", "key", "sleep", "log", "showText", "showImage")

        private fun gen(f: (String, String) -> String) = spec.joinToString("\n") { f(it.substringBefore(":"), it.substringAfter(":")) }

        fun preJs(): String = gen { n, p -> "function $n($p){return api.$n($p)}" } + "\n" + """
        function __lines(s){s=String(s);return s?s.split("\n"):[]}
        function sleep(ms){api.sleep(ms)} function wait(ms){api.sleep(ms)}
        function log(s){api.log(String(s))} function print(s){api.log(String(s))}
        var console={log:function(s){api.log(String(s))}}; console.warn=console.error=console.info=console.log;
        function getKey(){return String(api.key())}
        function findText(t){var p=api.findText(t);return p?{x:p.x,y:p.y}:null}
        function findAllText(t){return __lines(api.findAllText(t)).map(function(l){var p=l.split("|");return {x:+p[0],y:+p[1],text:p.slice(2).join("|")}})}
        function files(){return __lines(api.files())} function apps(){return __lines(api.apps())}
        function showText(t,s){api.showText(String(t),s||3)} function showImage(n,s){api.showImage(String(n),s||5)}
        function tap(x,y){api.click(x,y)} function longPress(x,y,ms){api.hold(x,y,ms||600)}
        function onTwoFingers(f){api.on("two",f)} function onOneFinger(f){api.on("one",f)}
        function onVolumeUp(f){api.on("volup",f)} function onVolumeDown(f){api.on("voldown",f)}
        function onBubble(f){api.on("bubble",f)} function onTouch(f){api.on("touch",f)}
        """.trimIndent()

        fun preLua(): String = gen { n, p -> "function $n($p) return api:$n($p) end" } + "\n" + """
        local function __lines(s) local t={} for l in string.gmatch(tostring(s),"[^\n]+") do t[#t+1]=l end return t end
        function sleep(ms) api:sleep(ms) end
        function wait(ms) api:sleep(ms) end
        function log(s) api:log(tostring(s)) end
        function print(...) local t={} for i=1,select('#',...) do t[i]=tostring((select(i,...))) end api:log(table.concat(t," ")) end
        function getKey() return api:key() end
        function findText(t) return api:findText(t) end
        function findAllText(t) return __lines(api:findAllText(t)) end
        function files() return __lines(api:files()) end
        function apps() return __lines(api:apps()) end
        function showText(t,s) api:showText(tostring(t),s or 3) end
        function showImage(n,s) api:showImage(tostring(n),s or 5) end
        function tap(x,y) api:click(x,y) end
        function longPress(x,y,ms) api:hold(x,y,ms or 600) end
        function onTwoFingers(f) _cb_two=f end
        function onOneFinger(f) _cb_one=f end
        function onVolumeUp(f) _cb_volup=f end
        function onVolumeDown(f) _cb_voldown=f end
        function onBubble(f) _cb_bubble=f end
        function onTouch(f) _cb_touch=f end
        """.trimIndent()

        fun preWeb(): String = gen { n, p ->
            if (n in asyncWeb) "function $n($p){return __a(\"$n\",[$p])}" else "function $n($p){return __c(\"$n\",[$p])}"
        } + "\n" + """
        var __cbs={},__pend={},__id=0;
        function __c(n,a){var r=api.call(n,JSON.stringify(a));return (r===""||r==null)?undefined:JSON.parse(r)}
        function __a(n,a){return new Promise(function(res){var i=++__id;__pend[i]=res;api.callAsync(n,JSON.stringify(a),i)})}
        function __res(i,v){var f=__pend[i];delete __pend[i];if(f)f(v)}
        function __fire(n){var f=__cbs[n];if(f){try{var r=f();if(r&&r.catch)r.catch(function(e){api.err(String(e))})}catch(e){api.err(String(e))}}}
        function __reg(n,f){__cbs[n]=f;__c("regCb",[n])}
        window.onerror=function(m,s,l){api.err("JS: "+m+" (linha "+l+")")};
        window.addEventListener("unhandledrejection",function(e){api.err("JS: "+String(e.reason))});
        function sleep(ms){return new Promise(function(r){setTimeout(r,ms)})} function wait(ms){return sleep(ms)}
        function log(s){api.log(String(s))} function print(s){api.log(String(s))}
        function getKey(){return __c("key",[])}
        function findText(t){var r=__c("findTextJson",[t]);return r?JSON.parse(r):null}
        function findAllText(t){var r=__c("findAllText",[t]);return r?r.split("\n").map(function(l){var p=l.split("|");return {x:+p[0],y:+p[1],text:p.slice(2).join("|")}}):[]}
        function files(){var r=__c("files",[]);return r?r.split("\n"):[]} function apps(){var r=__c("apps",[]);return r?r.split("\n"):[]}
        function showText(t,s){__c("showText",[String(t),s||3])} function showImage(n,s){__c("showImage",[String(n),s||5])}
        function tap(x,y){return click(x,y)} function longPress(x,y,ms){return hold(x,y,ms||600)}
        function onTwoFingers(f){__reg("two",f)} function onOneFinger(f){__reg("one",f)}
        function onVolumeUp(f){__reg("volup",f)} function onVolumeDown(f){__reg("voldown",f)}
        function onBubble(f){__reg("bubble",f)}
        """.trimIndent()
    }

    @Volatile var paused = false
    @Volatile var stopped = false
    var onArm: (() -> Unit)? = null
    var onSpam: ((Boolean) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    @Volatile var kind = "tap"
    @Volatile var armed = false
    var onPass: ((Boolean) -> Unit)? = null
    @Volatile var outX = 0
    @Volatile var outY = 0
    @Volatile var blocked = false
    @Volatile var delayMs = 0L
    @Volatile var tx = 0
    @Volatile var ty = 0
    var onShow: ((File, Int) -> Unit)? = null
    var onText: ((String, Int) -> Unit)? = null
    var onHtml: ((String) -> Unit)? = null              // HTML: o serviço carrega a página
    var onWeb: ((String) -> Unit)? = null               // HTML: executa JS na página
    var onWin: ((String, Int, Int, Int, Int) -> Unit)? = null
    var onQuit: (() -> Unit)? = null
    private var main: Thread? = null
    private var spamT: Thread? = null
    private val cbs = ConcurrentHashMap<String, Function>()
    private val webCbs = ConcurrentHashMap.newKeySet<String>()
    private var scope: Scriptable? = null
    private var luaG: Globals? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val pend = ArrayList<String>()
    private var mp: MediaPlayer? = null
    private var aiModel = ""
    private var lastAccWarn = 0L
    private val factory = StopFactory(this)
    private val api = Api()
    private val ui = Handler(Looper.getMainLooper())
    private val prefs by lazy { ctx.getSharedPreferences("data_" + dir.name, 0) }

    private fun err(e: Throwable) {
        Log.e("Automator", "erro: $e")
        if (!stopped && e !is StopErr && e !is InterruptedException && e.cause !is InterruptedException && e.cause !is StopErr)
            onError?.invoke(e.toString().take(300))
    }

    private fun warnAcc() {
        val t = System.currentTimeMillis()
        if (t - lastAccWarn > 5000) { lastAccWarn = t; onError?.invoke("Ative o Automator em Acessibilidade (comandos de toque não funcionam sem isso)") }
    }

    private fun gate() {
        while (paused && !stopped) Thread.sleep(100)
        if (stopped) throw StopErr()
    }

    private fun stopSpamInternal() {
        if (spamT != null) { spamT?.interrupt(); spamT = null; onSpam?.invoke(false) }
    }

    /** O script registrou um gatilho com esse nome? */
    fun has(name: String): Boolean = when (lang) {
        "Lua" -> luaG?.get("_cb_$name")?.isnil() == false
        "HTML" -> webCbs.contains(name)
        else -> cbs.containsKey(name)
    }

    private fun initTts() {
        if (tts != null) return
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                ttsReady = true
                synchronized(pend) { for (s in pend) tts?.speak(s, TextToSpeech.QUEUE_ADD, null, null); pend.clear() }
            }
        }
    }

    private fun postJson(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 45000
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toByteArray()) }
            val s = if (c.responseCode < 400) c.inputStream else c.errorStream
            return s?.bufferedReader()?.use { it.readText() } ?: ""
        } finally { c.disconnect() }
    }

    inner class Api {
        private fun svc(): ClickService? { val s = ClickService.inst; if (s == null) warnAcc(); return s }
        private fun safeFile(n: String) = File(dir, File(n).name)

        // ---------- Toque e gestos ----------
        fun click(x: Int, y: Int) {
            gate()
            val s = svc() ?: return
            if (armed) {
                try { onPass?.invoke(true); Thread.sleep(20); s.clickWait(x, y) }
                finally { onPass?.invoke(false) }
            } else s.click(x, y)
        }
        fun spam(x: Int, y: Int, ms: Int) {
            gate(); stopSpamInternal()
            val s = svc() ?: return
            val gap = ms.toLong().coerceAtLeast(10)
            spamT = thread {
                try {
                    while (!stopped) {
                        gate()
                        val t0 = System.currentTimeMillis()
                        s.clickWait(x, y)
                        val rest = gap - (System.currentTimeMillis() - t0)
                        if (rest > 0) Thread.sleep(rest)
                    }
                } catch (e: InterruptedException) {} catch (e: StopErr) {}
            }
            onSpam?.invoke(true)
        }
        fun stopSpam() { stopSpamInternal() }
        private fun passed(f: (ClickService) -> Unit) {
            gate()
            val s = svc() ?: return
            if (armed) { try { onPass?.invoke(true); Thread.sleep(20); f(s) } finally { onPass?.invoke(false) } } else f(s)
        }
        fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) { passed { it.swipeWait(x1, y1, x2, y2, ms) } }
        fun hold(x: Int, y: Int, ms: Int) { passed { it.holdWait(x, y, ms) } }
        fun doubleClick(x: Int, y: Int) { passed { it.clickWait(x, y); Thread.sleep(60); it.clickWait(x, y) } }
        fun pinch(x: Int, y: Int, from: Int, to: Int, ms: Int) { passed { it.pinchWait(x, y, from, to, ms) } }
        /** scroll("down") rola o conteúdo para baixo (dedo sobe). Aceita up/down/left/right/cima/baixo/esquerda/direita. */
        fun scroll(d: String) {
            val s = svc() ?: return
            val w = s.screenW(); val h = s.screenH()
            when (d.lowercase()) {
                "down", "baixo" -> swipe(w / 2, h * 7 / 10, w / 2, h * 3 / 10, 350)
                "up", "cima" -> swipe(w / 2, h * 3 / 10, w / 2, h * 7 / 10, 350)
                "left", "esquerda" -> swipe(w * 3 / 10, h / 2, w * 7 / 10, h / 2, 350)
                "right", "direita" -> swipe(w * 7 / 10, h / 2, w * 3 / 10, h / 2, 350)
            }
        }
        fun back() { gate(); svc()?.back() }
        fun home() { gate(); svc()?.home() }
        fun recents() { gate(); svc()?.recents() }
        fun notifications() { gate(); svc()?.notifications() }
        fun quickSettings() { gate(); svc()?.quickSettings() }
        fun powerMenu() { gate(); svc()?.powerMenu() }
        fun lockScreen() { gate(); svc()?.lockScreen() }
        fun screenshotKey() { gate(); svc()?.screenshotKey() }

        // ---------- Tela: texto ----------
        fun findText(t: String): Point? { gate(); return svc()?.find(t) }
        fun findTextJson(t: String): String { val p = findText(t) ?: return ""; return "{\"x\":${p.x},\"y\":${p.y}}" }
        fun findAllText(t: String): String { gate(); return svc()?.findAll(t)?.joinToString("\n") { "${it.first}|${it.second}|${it.third.replace("\n", " ")}" } ?: "" }
        fun clickText(t: String): Boolean { val p = findText(t) ?: return false; click(p.x, p.y); return true }
        fun waitText(t: String, ms: Int): Boolean {
            val end = System.currentTimeMillis() + ms.coerceAtLeast(0)
            do { gate(); if (svc()?.find(t) != null) return true; Thread.sleep(200) } while (System.currentTimeMillis() < end)
            return false
        }
        fun screenText(): String { gate(); return svc()?.screenText() ?: "" }
        fun typeText(t: String): Boolean { gate(); return svc()?.setText(t, false) ?: false }
        fun addText(t: String): Boolean { gate(); return svc()?.setText(t, true) ?: false }
        fun clearText(): Boolean { gate(); return svc()?.setText("", false) ?: false }
        fun paste(): Boolean { gate(); return svc()?.paste() ?: false }
        fun currentApp(): String { gate(); return svc()?.currentApp() ?: "" }
        fun screenW(): Int = ctx.resources.displayMetrics.widthPixels
        fun screenH(): Int = ctx.resources.displayMetrics.heightPixels

        // ---------- Tela: pixels (Android 11+) ----------
        fun screenshot(n: String): Boolean {
            gate()
            val b = svc()?.shotBitmap() ?: return false
            return try {
                dir.mkdirs()
                File(safeFile(if (n.contains(".")) n else "$n.png").path).outputStream().use { b.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                true
            } catch (_: Exception) { false }
        }
        fun pixel(x: Int, y: Int): String {
            gate()
            val b = svc()?.shotBitmap() ?: return ""
            if (x < 0 || y < 0 || x >= b.width || y >= b.height) return ""
            return String.format("#%06X", b.getPixel(x, y) and 0xFFFFFF)
        }
        /** Procura uma cor (#RRGGBB) na tela; devolve "x,y" ou "". tol = tolerância 0-255. */
        fun findColor(h: String, tol: Int): String {
            gate()
            val b = svc()?.shotBitmap() ?: return ""
            val want = try { Color.parseColor(h) } catch (_: Exception) { return "" }
            val tr = Color.red(want); val tg = Color.green(want); val tb = Color.blue(want)
            var y = 0
            while (y < b.height) {
                var x = 0
                while (x < b.width) {
                    val c = b.getPixel(x, y)
                    if (Math.abs(Color.red(c) - tr) <= tol && Math.abs(Color.green(c) - tg) <= tol && Math.abs(Color.blue(c) - tb) <= tol) return "$x,$y"
                    x += 3
                }
                y += 3
            }
            return ""
        }

        // ---------- Apps e sistema ----------
        fun openApp(n: String): Boolean {
            gate()
            return try {
                val pm = ctx.packageManager
                var intent = pm.getLaunchIntentForPackage(n)
                if (intent == null) {
                    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    val ri = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(n, true) }
                    if (ri != null) intent = pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
                }
                if (intent == null) false else {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    (ClickService.inst ?: ctx).startActivity(intent); true
                }
            } catch (_: Exception) { false }
        }
        fun apps(): String = try {
            val pm = ctx.packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.loadLabel(pm).toString() + "|" + it.activityInfo.packageName }.sorted().joinToString("\n")
        } catch (_: Exception) { "" }
        fun openUrl(u: String): Boolean {
            gate()
            return try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                (ClickService.inst ?: ctx).startActivity(i); true
            } catch (_: Exception) { false }
        }
        @Suppress("DEPRECATION")
        fun vibrate(ms: Int) {
            gate()
            try { ctx.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(ms.toLong().coerceAtLeast(1), VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_: Exception) {}
        }
        fun toast(t: String) { ui.post { Toast.makeText(ctx, t, Toast.LENGTH_LONG).show() } }
        fun flashlight(on: Boolean) {
            gate()
            try { val cm = ctx.getSystemService(CameraManager::class.java); cm.setTorchMode(cm.cameraIdList[0], on) } catch (_: Exception) {}
        }
        fun battery(): Int = try { ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) } catch (_: Exception) { -1 }
        fun getVolume(): Int = try {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        } catch (_: Exception) { -1 }
        fun setVolume(p: Int) {
            gate()
            try {
                val am = ctx.getSystemService(AudioManager::class.java)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, p.coerceIn(0, 100) * am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) / 100, 0)
            } catch (_: Exception) {}
        }
        fun getClipboard(): String = try {
            ctx.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString() ?: ""
        } catch (_: Exception) { "" }
        fun setClipboard(t: String) {
            try { ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("a", t)) } catch (_: Exception) {}
        }
        fun date(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        fun hour(): Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        fun minute(): Int = Calendar.getInstance().get(Calendar.MINUTE)
        fun now(): Double = System.currentTimeMillis().toDouble()

        // ---------- Voz e IA ----------
        fun speak(t: String) {
            initTts()
            if (ttsReady) tts?.speak(t, TextToSpeech.QUEUE_ADD, null, null) else synchronized(pend) { pend.add(t) }
        }
        fun stopSpeak() { try { tts?.stop() } catch (_: Exception) {}; synchronized(pend) { pend.clear() } }
        fun readScreen() {
            val t = screenText()
            if (t.isBlank()) speak("Não achei texto na tela") else t.chunked(3500).forEach { speak(it) }
        }
        /** Escuta o microfone e devolve o que a pessoa falou ("" se nada; "ERRO: ..." se falhar). */
        fun listen(ms: Int): String {
            gate()
            if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return "ERRO: reconhecimento de voz indisponível"
            val l = CountDownLatch(1)
            var res = ""
            var sr: SpeechRecognizer? = null
            val h = Handler(Looper.getMainLooper())
            h.post {
                try {
                    val r = SpeechRecognizer.createSpeechRecognizer(ctx); sr = r
                    r.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(p: android.os.Bundle?) {}
                        override fun onBeginningOfSpeech() {}
                        override fun onRmsChanged(v: Float) {}
                        override fun onBufferReceived(b: ByteArray?) {}
                        override fun onEndOfSpeech() {}
                        override fun onError(c: Int) { l.countDown() }
                        override fun onResults(b: android.os.Bundle?) {
                            res = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; l.countDown()
                        }
                        override fun onPartialResults(b: android.os.Bundle?) {}
                        override fun onEvent(t: Int, b: android.os.Bundle?) {}
                    })
                    r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR"))
                } catch (e: Exception) { res = "ERRO: " + e.message; l.countDown() }
            }
            l.await(ms.coerceIn(2000, 60000).toLong(), TimeUnit.MILLISECONDS)
            h.post { try { sr?.destroy() } catch (_: Exception) {} }
            return res
        }
        fun setAiModel(m: String) { aiModel = m }
        /** Pergunta para a IA usando a chave salva (Anthropic sk-ant..., OpenAI sk-..., Gemini AIza...). */
        fun ai(p: String): String {
            gate()
            val k = Store.key(ctx).trim()
            if (k.isEmpty()) return "ERRO: salve a chave de API na tela inicial do Automator"
            return try {
                when {
                    k.startsWith("sk-ant") -> {
                        val b = JSONObject().put("model", if (aiModel.isEmpty()) "claude-haiku-5-5" else aiModel).put("max_tokens", 1024)
                            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", p)))
                        val r = JSONObject(postJson("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to k, "anthropic-version" to "2023-06-01"), b.toString()))
                        if (r.has("error")) "ERRO: " + r.getJSONObject("error").optString("message")
                        else r.getJSONArray("content").getJSONObject(0).optString("text")
                    }
                    k.startsWith("AIza") -> {
                        val m = if (aiModel.isEmpty()) "gemini-2.0-flash" else aiModel
                        val b = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", p)))))
                        val r = JSONObject(postJson("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent?key=" + k, emptyMap(), b.toString()))
                        if (r.has("error")) "ERRO: " + r.getJSONObject("error").optString("message")
                        else r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text")
                    }
                    else -> {
                        val b = JSONObject().put("model", if (aiModel.isEmpty()) "gpt-4o-mini" else aiModel)
                            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", p)))
                        val r = JSONObject(postJson("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer " + k), b.toString()))
                        if (r.has("error")) "ERRO: " + r.getJSONObject("error").optString("message")
                        else r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")
                    }
                }
            } catch (e: Exception) { "ERRO: " + e.message }
        }
        /** Lê a tela e responde a pergunta usando a IA. */
        fun askScreen(q: String): String =
            ai("Texto que está na tela do celular agora:\n" + screenText().take(12000) + "\n\nPergunta: " + q + "\nResponda curto, em português.")

        // ---------- Mídia ----------
        fun playAudio(n: String) {
            gate(); stopAudio()
            try {
                val p = MediaPlayer()
                if (n.startsWith("http")) p.setDataSource(n) else p.setDataSource(safeFile(n).path)
                p.prepare(); p.start(); mp = p
            } catch (e: Exception) { onError?.invoke("Áudio: " + e.message) }
        }
        fun stopAudio() { try { mp?.release() } catch (_: Exception) {}; mp = null }
        fun showText(t: String, sec: Int) { onText?.invoke(t, sec) }
        fun showImage(n: String, sec: Int) { onShow?.invoke(safeFile(n), sec) }
        fun files(): String = dir.list()?.sorted()?.joinToString("\n") ?: ""

        // ---------- Dados e arquivos ----------
        fun saveData(k: String, v: String) { prefs.edit().putString(k, v).apply() }
        fun loadData(k: String): String = prefs.getString(k, "") ?: ""
        fun readFile(n: String): String = try { safeFile(n).readText() } catch (_: Exception) { "" }
        fun writeFile(n: String, t: String): Boolean = try { dir.mkdirs(); safeFile(n).writeText(t); true } catch (_: Exception) { false }
        fun deleteFile(n: String): Boolean = try { safeFile(n).delete() } catch (_: Exception) { false }

        // ---------- Rede ----------
        fun post(url: String, auth: String, body: String): String {
            gate()
            return try { postJson(url, if (auth.isNotEmpty()) mapOf("Authorization" to auth) else emptyMap(), body) } catch (e: Exception) { "ERRO: " + e.message }
        }
        fun httpGet(url: String, auth: String): String {
            gate()
            return try {
                val c = URL(url).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 15000; c.readTimeout = 30000
                    if (auth.isNotEmpty()) c.setRequestProperty("Authorization", auth)
                    val s = if (c.responseCode < 400) c.inputStream else c.errorStream
                    s?.bufferedReader()?.use { it.readText() } ?: ""
                } finally { c.disconnect() }
            } catch (e: Exception) { "ERRO: " + e.message }
        }

        // ---------- Controle ----------
        fun sleep(ms: Int) {
            var left = ms.toLong()
            while (left > 0) { val s = if (left > 100) 100L else left; Thread.sleep(s); left -= s; gate() }
            gate()
        }
        fun key(): String = Store.key(ctx)
        fun log(s: String) { Log.d("Automator", s) }
        fun quit() { onQuit?.invoke() }
        fun touchKind(): String = kind
        fun touchX(): Int = tx
        fun touchY(): Int = ty
        fun setTouch(x: Int, y: Int) { outX = x; outY = y }
        fun delayTouch(ms: Int) { delayMs = ms.toLong().coerceAtLeast(0L) }
        fun blockTouch() { blocked = true }
        fun on(name: String, f: Any) { if (f is Function) cbs[name] = f }
        fun regCb(name: String) { webCbs.add(name) }

        // ---------- Janela HTML ----------
        fun winShow() { onWin?.invoke("show", 0, 0, 0, 0) }
        fun winHide() { onWin?.invoke("hide", 0, 0, 0, 0) }
        fun setWindow(x: Int, y: Int, w: Int, h: Int) { onWin?.invoke("geom", x, y, w, h) }
        fun winFocus(on: Boolean) { onWin?.invoke(if (on) "focus1" else "focus0", 0, 0, 0, 0) }
    }

    /** Ponte da página HTML: um único ponto de entrada que chama qualquer método de Api pelo nome. */
    inner class WebApi {
        @JavascriptInterface fun call(name: String, args: String): String = try { webCall(name, args) } catch (e: Throwable) { this@Engine.err(e); "null" }
        @JavascriptInterface fun callAsync(name: String, args: String, id: Int) {
            thread {
                val r = try { webCall(name, args) } catch (e: Throwable) { this@Engine.err(e); "null" }
                if (!stopped) onWeb?.invoke("__res($id,$r)")
            }
        }
        @JavascriptInterface fun log(s: String) { Log.d("Automator", s) }
        @JavascriptInterface fun err(s: String) { Log.e("Automator", s); if (!stopped) onError?.invoke(s.take(300)) }
    }

    private fun webCall(name: String, args: String): String {
        if (name !in apiNames) return "null"
        val arr = JSONArray(args)
        val m = Api::class.java.methods.firstOrNull { it.name == name && it.parameterTypes.size == arr.length() } ?: return "null"
        val a = arrayOfNulls<Any>(arr.length())
        for (i in a.indices) {
            a[i] = when (m.parameterTypes[i].name) {
                "int" -> arr.optDouble(i, 0.0).toInt()
                "long" -> arr.optDouble(i, 0.0).toLong()
                "double" -> arr.optDouble(i, 0.0)
                "boolean" -> arr.optBoolean(i)
                else -> if (arr.isNull(i)) "" else arr.optString(i)
            }
        }
        val r = try { m.invoke(api, *a) } catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
        return when (r) {
            null -> "null"
            is String -> JSONObject.quote(r)
            is Boolean -> r.toString()
            is Number -> r.toString()
            else -> "null"
        }
    }

    fun start(code: String) {
        stopped = false; paused = false; current = this
        initTts()
        if (lang == "HTML") { onHtml?.invoke(code); return }
        main = thread {
            try {
                if (lang == "Lua") {
                    val g = JsePlatform.standardGlobals(); luaG = g
                    g.set("api", CoerceJavaToLua.coerce(api))
                    g.load(preLua() + "\n" + code).call()
                } else {
                    val cx = factory.enterContext()
                    try {
                        val s = cx.initStandardObjects(); scope = s
                        ScriptableObject.putProperty(s, "api", JsCtx.javaToJS(api, s))
                        cx.evaluateString(s, preJs() + "\n" + code, "script", 1, null)
                    } finally { JsCtx.exit() }
                }
            } catch (e: Throwable) { err(e) }
        }
    }

    /** Passa o toque pelo onTouch do script ANTES de ir pra tela. null = bloqueado. Sem onTouch: não gasta nada. */
    fun convert(x: Int, y: Int): IntArray? {
        if (!has("touch")) return intArrayOf(x, y)
        outX = x; outY = y; blocked = false; delayMs = 0L; tx = x; ty = y
        val th = thread {
            try {
                if (lang == "Lua") {
                    val fn = luaG?.get("_cb_touch")
                    if (fn != null && !fn.isnil()) fn.call(LuaValue.valueOf(x), LuaValue.valueOf(y))
                } else {
                    val f = cbs["touch"]
                    if (f != null) {
                        val cx = factory.enterContext()
                        try { f.call(cx, scope, scope, arrayOf<Any>(x.toDouble(), y.toDouble())) } finally { JsCtx.exit() }
                    }
                }
            } catch (e: Throwable) { err(e) }
        }
        try { th.join(120) } catch (_: InterruptedException) {}
        return if (blocked) null else intArrayOf(outX, outY)
    }

    fun fire() = fire("two")
    fun fireOne() = fire("one")

    fun fire(name: String) {
        if (stopped) return
        when (lang) {
            "Lua" -> {
                val fn = luaG?.get("_cb_$name") ?: return
                if (fn.isnil()) return
                thread { try { fn.call() } catch (e: Throwable) { err(e) } }
            }
            "HTML" -> onWeb?.invoke("__fire('$name')")
            else -> {
                val f = cbs[name] ?: return
                thread {
                    val cx = factory.enterContext()
                    try { f.call(cx, scope, scope, arrayOf()) } catch (e: Throwable) { err(e) } finally { JsCtx.exit() }
                }
            }
        }
    }

    fun stop() {
        stopped = true; stopSpamInternal(); main?.interrupt()
        if (current === this) current = null
        try { mp?.release() } catch (_: Exception) {}; mp = null
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}; tts = null
    }
}
