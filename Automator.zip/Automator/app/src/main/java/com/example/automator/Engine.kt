package com.example.automator
import android.content.Context
import android.graphics.Point
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.util.Log
import org.luaj.vm2.Globals
import org.luaj.vm2.lib.jse.CoerceJavaToLua
import org.luaj.vm2.lib.jse.JsePlatform
import org.mozilla.javascript.Context as JsCtx
import org.mozilla.javascript.Function
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class Engine(private val ctx: Context, private val dir: File, private val lang: String = "JavaScript") {
    @Volatile var paused = false
    @Volatile var stopped = false
    var onArm: (() -> Unit)? = null
    var onSpam: ((Boolean) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    @Volatile var tx = 0
    @Volatile var ty = 0
    var onShow: ((File, Int) -> Unit)? = null
    private var main: Thread? = null
    private var spamT: Thread? = null
    private var cb: Function? = null
    private var cbOne: Function? = null
    private var scope: Scriptable? = null
    private var luaG: Globals? = null
    private var tts: TextToSpeech? = null
    private var mp: MediaPlayer? = null

    private val preJs = """
        function click(x,y){api.click(x,y)} function spam(x,y,ms){api.spam(x,y,ms)}
        function stopSpam(){api.stopSpam()} function sleep(ms){api.sleep(ms)}
        function findText(t){return api.findText(t)} function clickText(t){return api.clickText(t)}
        function speak(t){api.speak(t)} function getKey(){return api.key()}
        function post(u,a,b){return api.post(u,a,b)} function log(s){api.log(String(s))}
        function onTwoFingers(f){api.onTwoFingers(f)} function onOneFinger(f){api.onOneFinger(f)}
        function touchX(){return api.touchX()} function touchY(){return api.touchY()}
        function playAudio(n){api.playAudio(n)} function stopAudio(){api.stopAudio()}
        function showImage(n,s){api.showImage(n,s||5)} function files(){return String(api.files()).split("\n")}
    """.trimIndent()

    private val preLua = """
        function click(x,y) api:click(x,y) end
        function spam(x,y,ms) api:spam(x,y,ms) end
        function stopSpam() api:stopSpam() end
        function sleep(ms) api:sleep(ms) end
        function findText(t) return api:findText(t) end
        function clickText(t) return api:clickText(t) end
        function speak(t) api:speak(t) end
        function getKey() return api:key() end
        function post(u,a,b) return api:post(u,a,b) end
        function log(s) api:log(tostring(s)) end
        function onTwoFingers(f) _cb2=f api:armTouch() end
        function onOneFinger(f) _cb1=f api:armTouch() end
        function touchX() return api:touchX() end
        function touchY() return api:touchY() end
        function playAudio(n) api:playAudio(n) end
        function stopAudio() api:stopAudio() end
        function showImage(n,s) api:showImage(n,s or 5) end
        function files() local t={} for l in string.gmatch(api:files(),"[^\n]+") do t[#t+1]=l end return t end
    """.trimIndent()

    private fun err(e: Throwable) {
        Log.e("Automator", "erro: $e")
        if (!stopped && e !is InterruptedException && e.cause !is InterruptedException) onError?.invoke(e.toString().take(300))
    }

    private fun gate() {
        while (paused && !stopped) Thread.sleep(100)
        if (stopped) throw InterruptedException()
    }

    private fun stopSpamInternal() {
        if (spamT != null) { spamT?.interrupt(); spamT = null; onSpam?.invoke(false) }
    }

    inner class Api {
        fun click(x: Int, y: Int) { gate(); ClickService.inst?.click(x, y) }
        fun spam(x: Int, y: Int, ms: Int) {
            stopSpamInternal()
            val gap = ms.toLong().coerceAtLeast(10)
            spamT = thread {
                try {
                    while (!stopped) {
                        gate()
                        val t0 = System.currentTimeMillis()
                        ClickService.inst?.clickWait(x, y)
                        val rest = gap - (System.currentTimeMillis() - t0)
                        if (rest > 0) Thread.sleep(rest)
                    }
                } catch (e: InterruptedException) {}
            }
            onSpam?.invoke(true)
        }
        fun stopSpam() { stopSpamInternal() }
        fun sleep(ms: Int) { Thread.sleep(ms.toLong()); gate() }
        fun findText(t: String): Point? = ClickService.inst?.find(t)
        fun clickText(t: String): Boolean { val p = findText(t) ?: return false; click(p.x, p.y); return true }
        fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_ADD, null, null) }
        fun key(): String = Store.key(ctx)
        fun log(s: String) { Log.d("Automator", s) }
        fun touchX(): Int = tx
        fun touchY(): Int = ty
        fun armTouch() { onArm?.invoke() }
        fun onOneFinger(f: Any) { cbOne = f as? Function; onArm?.invoke() }
        fun onTwoFingers(f: Any) { cb = f as? Function; onArm?.invoke() }
        fun files(): String = dir.list()?.sorted()?.joinToString("\n") ?: ""
        fun playAudio(n: String) {
            stopAudio()
            mp = MediaPlayer().apply { setDataSource(File(dir, n).path); prepare(); start() }
        }
        fun stopAudio() { try { mp?.release() } catch (_: Exception) {}; mp = null }
        fun showImage(n: String, sec: Int) { onShow?.invoke(File(dir, n), sec) }
        fun post(url: String, auth: String, body: String): String {
            gate()
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            if (auth.isNotEmpty()) c.setRequestProperty("Authorization", auth)
            c.outputStream.use { it.write(body.toByteArray()) }
            val s = if (c.responseCode < 400) c.inputStream else c.errorStream
            return s.bufferedReader().readText()
        }
    }

    fun start(code: String) {
        stopped = false; paused = false
        tts = TextToSpeech(ctx) { tts?.language = Locale("pt", "BR") }
        main = thread {
            try {
                if (lang == "Lua") {
                    val g = JsePlatform.standardGlobals(); luaG = g
                    g.set("api", CoerceJavaToLua.coerce(Api()))
                    g.load(preLua + "\n" + code).call()
                } else {
                    val cx = JsCtx.enter(); cx.optimizationLevel = -1
                    try {
                        val s = cx.initStandardObjects(); scope = s
                        ScriptableObject.putProperty(s, "api", JsCtx.javaToJS(Api(), s))
                        cx.evaluateString(s, preJs + "\n" + code, "script", 1, null)
                    } finally { JsCtx.exit() }
                }
            } catch (e: Throwable) { err(e) }
        }
    }

    fun fire() = dispatch(false)
    fun fireOne() = dispatch(true)

    private fun dispatch(one: Boolean) {
        if (lang == "Lua") {
            val fn = luaG?.get(if (one) "_cb1" else "_cb2") ?: return
            if (fn.isnil()) return
            thread { try { fn.call() } catch (e: Throwable) { err(e) } }
        } else {
            val f = (if (one) cbOne else cb) ?: return
            thread {
                val cx = JsCtx.enter(); cx.optimizationLevel = -1
                try { f.call(cx, scope, scope, arrayOf()) } catch (e: Throwable) { err(e) } finally { JsCtx.exit() }
            }
        }
    }

    fun stop() {
        stopped = true; stopSpamInternal(); main?.interrupt()
        try { mp?.release() } catch (_: Exception) {}; mp = null
        tts?.shutdown(); tts = null
    }
}
