package com.example.rec

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.Surface
import android.view.WindowManager
import android.widget.Toast
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class RecService : Service() {
    companion object {
        const val ACTION_START = "com.example.rec.START"
        const val ACTION_STOP = "com.example.rec.STOP"
        const val SR = 48000
        @Volatile var recording = false
        var listener: ((Boolean) -> Unit)? = null
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var vEnc: MediaCodec? = null
    private var aEnc: MediaCodec? = null
    private var surface: Surface? = null
    private var muxer: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var intRec: AudioRecord? = null
    private var micRec: AudioRecord? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    @Volatile private var running = false
    private var stopping = false
    private var startUs = 0L
    private val muxLock = Any()
    private var expected = 1
    private var added = 0
    @Volatile private var started = false
    private var latch = CountDownLatch(1)
    private var vTrack = -1
    private var aTrack = -1
    @Volatile private var wroteAny = false
    private var vOffset = Long.MIN_VALUE
    private var lastV = -1L
    private var lastA = -1L
    private var prevTouch = 0
    private var prevPtr = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        when (i?.action) {
            ACTION_STOP -> stopRec()
            ACTION_START -> startRec(i)
        }
        return START_NOT_STICKY
    }

    private fun toast(m: String) { main.post { Toast.makeText(applicationContext, m, Toast.LENGTH_LONG).show() } }

    private fun goForeground(mic: Boolean) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Gravação", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, RecService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Gravando")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Parar", stop).build())
            .setOngoing(true)
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (mic && Build.VERSION.SDK_INT >= 30) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        startForeground(1, n, type)
    }

    @Suppress("DEPRECATION")
    private fun startRec(i: Intent) {
        if (recording || running) return
        stopping = false
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val fps = p.getInt("fps", 60)
        val mbps = p.getInt("mbps", 16)
        val q = p.getInt("q", 1080)
        val land = p.getBoolean("land", true)
        val audio = p.getInt("audio", 2)
        val useInt = audio == 0 || audio == 2
        val useMic = audio == 1 || audio == 2
        try {
            goForeground(useMic)
            val code = i.getIntExtra("code", 0)
            val data = i.getParcelableExtra<Intent>("data")!!
            val proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopRec() } }
            }, main)

            // tamanho do vídeo
            val dm = DisplayMetrics()
            getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(dm)
            val shortS = minOf(dm.widthPixels, dm.heightPixels)
            val longS = maxOf(dm.widthPixels, dm.heightPixels)
            val tShort = (if (q == 0) shortS else minOf(q, shortS)) / 2 * 2
            val tLong = (longS.toLong() * tShort / shortS).toInt() / 2 * 2
            val vw = if (land) tLong else tShort
            val vh = if (land) tShort else tLong

            // saída na galeria
            val name = "REC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val cv = ContentValues()
            cv.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Rec")
            cv.put(MediaStore.Video.Media.IS_PENDING, 1)
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            uri = u
            val fd = contentResolver.openFileDescriptor(u, "rw")!!
            pfd = fd
            muxer = MediaMuxer(fd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            // encoder de vídeo
            val vf = MediaFormat.createVideoFormat("video/avc", vw, vh)
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            vf.setInteger(MediaFormat.KEY_BIT_RATE, mbps * 1_000_000)
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            vf.setInteger(MediaFormat.KEY_PRIORITY, 0)
            vf.setInteger(MediaFormat.KEY_OPERATING_RATE, fps)
            val ve = MediaCodec.createEncoderByType("video/avc")
            ve.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = ve.createInputSurface()
            ve.start()
            vEnc = ve

            // áudio
            val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT) * 4
            if (useInt) {
                try {
                    val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()
                    val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
                    intRec = AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(min)
                        .setAudioPlaybackCaptureConfig(cfg).build()
                } catch (e: Throwable) { intRec = null }
            }
            if (useMic) {
                try {
                    val mm = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT) * 4
                    val r = AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, mm)
                    micRec = if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
                } catch (e: Throwable) { micRec = null }
            }
            val hasAudio = intRec != null || micRec != null
            if (hasAudio) {
                val af = MediaFormat.createAudioFormat("audio/mp4a-latm", SR, 2)
                af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                af.setInteger(MediaFormat.KEY_BIT_RATE, 192000)
                af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
                val ae = MediaCodec.createEncoderByType("audio/mp4a-latm")
                ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                ae.start()
                aEnc = ae
            }
            expected = if (hasAudio) 2 else 1
            added = 0; started = false; wroteAny = false
            latch = CountDownLatch(1)
            vTrack = -1; aTrack = -1; vOffset = Long.MIN_VALUE; lastV = -1; lastA = -1

            startUs = System.nanoTime() / 1000
            display = proj.createVirtualDisplay("rec", vw, vh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)

            running = true
            vThread = Thread({ drain(ve, true, true) }, "rec-v").also { it.start() }
            if (hasAudio) aThread = Thread({ audioLoop() }, "rec-a").also { it.start() }

            prevTouch = Touch.get(this, "show_touches")
            prevPtr = Touch.get(this, "pointer_location")
            runScript("onStart")

            recording = true
            main.post { listener?.invoke(true) }
        } catch (e: Throwable) {
            toast("Erro: " + e.message)
            running = false
            stopping = true
            Thread { release(true); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }.start()
        }
    }

    private fun addTrack(fmt: MediaFormat, video: Boolean) {
        synchronized(muxLock) {
            val m = muxer ?: return
            val t = m.addTrack(fmt)
            if (video) vTrack = t else aTrack = t
            added++
            if (added == expected) { m.start(); started = true; latch.countDown() }
        }
    }

    // retorna true quando chegou no fim do stream
    private fun drain(enc: MediaCodec, video: Boolean, block: Boolean, maxTries: Int = Int.MAX_VALUE): Boolean {
        val info = MediaCodec.BufferInfo()
        var tries = 0
        while (true) {
            val idx = try { enc.dequeueOutputBuffer(info, if (block) 10000L else 0L) } catch (e: Exception) { return true }
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!block) return false
                if (++tries >= maxTries) return false
                continue
            }
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { addTrack(enc.outputFormat, video); continue }
            if (idx < 0) continue
            val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
            if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
            if (info.size > 0) {
                if (!started) { try { latch.await(1, TimeUnit.SECONDS) } catch (e: InterruptedException) {} }
                if (started) {
                    val buf = enc.getOutputBuffer(idx)
                    if (buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        var pts = info.presentationTimeUs
                        if (video) {
                            if (vOffset == Long.MIN_VALUE) {
                                val now = System.nanoTime() / 1000
                                vOffset = if (Math.abs(now - pts) < 5_000_000L) 0L else now - pts
                            }
                            pts = (pts + vOffset - startUs).coerceAtLeast(0)
                            if (pts <= lastV) pts = lastV + 1
                            lastV = pts
                        } else {
                            if (pts <= lastA) pts = lastA + 1
                            lastA = pts
                        }
                        info.presentationTimeUs = pts
                        synchronized(muxLock) {
                            try {
                                muxer?.writeSampleData(if (video) vTrack else aTrack, buf, info)
                                wroteAny = true
                            } catch (e: Exception) {}
                        }
                    }
                }
            }
            try { enc.releaseOutputBuffer(idx, false) } catch (e: Exception) {}
            if (eos) return true
        }
    }

    private fun readAll(r: AudioRecord, b: ShortArray, size: Int): Boolean {
        var off = 0
        while (off < size && running) {
            val n = r.read(b, off, size - off)
            if (n < 0) return false
            off += n
        }
        return off == size
    }

    private fun feed(enc: MediaCodec, data: ByteArray, size: Int, pts: Long, flags: Int) {
        val idx = enc.dequeueInputBuffer(10000)
        if (idx >= 0) {
            val ib = enc.getInputBuffer(idx)!!
            ib.clear()
            if (size > 0) ib.put(data, 0, size)
            enc.queueInputBuffer(idx, 0, size, pts, flags)
        }
    }

    private fun audioLoop() {
        val enc = aEnc ?: return
        val frames = 1024
        val st = ShortArray(frames * 2)
        val mono = ShortArray(frames)
        val mix = ShortArray(frames * 2)
        val bytes = ByteArray(frames * 4)
        val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        try {
            // um bloco de silêncio para o encoder liberar o formato logo
            feed(enc, ByteArray(frames * 4), frames * 4, 0, 0)
            drain(enc, false, false)
            intRec?.startRecording()
            micRec?.startRecording()
            var total = 0L
            var base = -1L
            while (running) {
                if (intRec != null && !readAll(intRec!!, st, frames * 2)) break
                if (micRec != null && !readAll(micRec!!, mono, frames)) break
                if (!running) break
                if (base < 0) {
                    base = (System.nanoTime() / 1000 - startUs - frames * 1_000_000L / SR).coerceAtLeast(0)
                }
                for (k in 0 until frames) {
                    val m = if (micRec != null) mono[k].toInt() else 0
                    val l = (if (intRec != null) st[2 * k].toInt() else 0) + m
                    val r = (if (intRec != null) st[2 * k + 1].toInt() else 0) + m
                    mix[2 * k] = l.coerceIn(-32768, 32767).toShort()
                    mix[2 * k + 1] = r.coerceIn(-32768, 32767).toShort()
                }
                sb.clear(); sb.put(mix)
                feed(enc, bytes, frames * 4, base + total * 1_000_000L / SR, 0)
                total += frames
                drain(enc, false, false)
            }
            feed(enc, bytes, 0, base.coerceAtLeast(0) + total * 1_000_000L / SR, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(enc, false, true, 200)
        } catch (e: Throwable) {}
    }

    private fun runScript(fn: String) {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        var code = p.getString("script", "") ?: ""
        if (code.isBlank()) code = Cfg.DEFAULT_SCRIPT
        val on = p.getBoolean("touch", false)
        val cx = org.mozilla.javascript.Context.enter()
        try {
            cx.optimizationLevel = -1
            val scope = cx.initStandardObjects()
            org.mozilla.javascript.ScriptableObject.putProperty(
                scope, "rec", org.mozilla.javascript.Context.javaToJS(ScriptApi(applicationContext, main), scope))
            cx.evaluateString(scope, code, "script", 1, null)
            val f = scope.get(fn, scope)
            if (f is org.mozilla.javascript.Function) f.call(cx, scope, scope, arrayOf<Any>(on))
        } catch (e: Throwable) {
            toast("Script: " + e.message)
        } finally {
            org.mozilla.javascript.Context.exit()
        }
    }

    private fun stopRec() {
        if (stopping) return
        stopping = true
        if (vEnc == null) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return }
        Thread { finish() }.start()
    }

    private fun finish() {
        running = false
        runScript("onStop")
        Touch.set(this, "show_touches", prevTouch == 1)
        Touch.set(this, "pointer_location", prevPtr == 1)
        try { vEnc?.signalEndOfInputStream() } catch (e: Throwable) {}
        try { aThread?.join(5000) } catch (e: Throwable) {}
        try { vThread?.join(5000) } catch (e: Throwable) {}
        release(false)
        recording = false
        main.post {
            listener?.invoke(false)
            Toast.makeText(applicationContext, if (wroteAny) "Vídeo salvo na galeria" else "Nada gravado", Toast.LENGTH_SHORT).show()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun release(failed: Boolean) {
        try { synchronized(muxLock) { if (started) muxer?.stop() } } catch (e: Throwable) {}
        try { muxer?.release() } catch (e: Throwable) {}
        try { display?.release() } catch (e: Throwable) {}
        try { surface?.release() } catch (e: Throwable) {}
        try { vEnc?.stop() } catch (e: Throwable) {}
        try { vEnc?.release() } catch (e: Throwable) {}
        try { aEnc?.stop() } catch (e: Throwable) {}
        try { aEnc?.release() } catch (e: Throwable) {}
        try { intRec?.stop() } catch (e: Throwable) {}
        try { intRec?.release() } catch (e: Throwable) {}
        try { micRec?.stop() } catch (e: Throwable) {}
        try { micRec?.release() } catch (e: Throwable) {}
        try { projection?.stop() } catch (e: Throwable) {}
        try { pfd?.close() } catch (e: Throwable) {}
        val u = uri
        if (u != null) {
            try {
                if (wroteAny && !failed) {
                    val cv = ContentValues()
                    cv.put(MediaStore.Video.Media.IS_PENDING, 0)
                    contentResolver.update(u, cv, null, null)
                } else contentResolver.delete(u, null, null)
            } catch (e: Throwable) {}
        }
        muxer = null; display = null; surface = null; vEnc = null; aEnc = null
        intRec = null; micRec = null; projection = null; pfd = null; uri = null
    }
}
