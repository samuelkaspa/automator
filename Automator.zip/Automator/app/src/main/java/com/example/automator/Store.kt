package com.example.automator
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    private fun p(c: Context) = c.getSharedPreferences("s", 0)
    fun scripts(c: Context): MutableList<Pair<String, String>> {
        val a = JSONArray(p(c).getString("scripts", "[]"))
        return MutableList(a.length()) { val o = a.getJSONObject(it); o.getString("n") to o.getString("c") }
    }
    fun save(c: Context, l: List<Pair<String, String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("n", it.first).put("c", it.second)) }
        p(c).edit().putString("scripts", a.toString()).apply()
    }
    fun key(c: Context) = p(c).getString("key", "") ?: ""
    fun setKey(c: Context, k: String) = p(c).edit().putString("key", k).apply()
}
