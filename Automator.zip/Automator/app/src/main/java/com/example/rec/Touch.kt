package com.example.rec

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.provider.Settings
import android.widget.Toast

object Cfg {
    const val DEFAULT_SCRIPT = """// Roda quando a gravação começa (onStart) e quando termina (onStop).
// 'ligado' = estado do botão "Mostrar toques".
// rec.touches(true/false)  mostra/esconde os toques na tela
// rec.pointer(true/false)  mostra coordenadas e rastro dos toques
// rec.toast("texto")
function onStart(ligado) {
  rec.touches(ligado);
}
function onStop(ligado) {
  rec.touches(false);
  rec.pointer(false);
}
"""
}

object Touch {
    fun canWrite(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    fun get(c: Context, key: String): Int =
        try { Settings.System.getInt(c.contentResolver, key, 0) } catch (e: Exception) { 0 }

    fun set(c: Context, key: String, on: Boolean) {
        try { Settings.System.putInt(c.contentResolver, key, if (on) 1 else 0) } catch (e: Exception) {}
    }
}

class ScriptApi(private val c: Context, private val h: Handler) {
    fun touches(on: Boolean) = Touch.set(c, "show_touches", on)
    fun pointer(on: Boolean) = Touch.set(c, "pointer_location", on)
    fun toast(m: String) { h.post { Toast.makeText(c, m, Toast.LENGTH_SHORT).show() } }
}
