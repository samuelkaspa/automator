package com.example.rec

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.provider.Settings
import android.widget.Toast
import rikka.shizuku.Shizuku

object Cfg {
    const val DEFAULT_SCRIPT = """// Roda quando a gravação começa (onStart) e quando termina (onStop).
// 'ligado' = estado do botão "Mostrar toques".
// rec.touches(true/false)  mostra/esconde os toques na tela
// rec.pointer(true/false)  mostra coordenadas e rastro dos toques (pesado)
// rec.micPitch(-12..12)    altura da sua voz, em semitons (muda ao vivo)
// rec.gamePitch(-12..12)   altura da voz/áudio do jogo, em semitons (muda ao vivo)
// rec.toast("texto")
function onStart(ligado) {
  rec.touches(ligado);
}
function onStop(ligado) {
  rec.touches(false);
  rec.pointer(false);
}
"""
}

object Touch {
    const val PERM = "android.permission.WRITE_SECURE_SETTINGS"

    fun canWrite(c: Context) = c.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    fun get(c: Context, key: String): Int =
        try { Settings.System.getInt(c.contentResolver, key, 0) } catch (e: Exception) { 0 }

    fun set(c: Context, key: String, on: Boolean) {
        try { Settings.System.putInt(c.contentResolver, key, if (on) 1 else 0) } catch (e: Exception) {}
    }
}

/**
 * Concede WRITE_SECURE_SETTINGS ao próprio app SEM computador, usando o Shizuku
 * (que se inicia pela "Depuração sem fio" do próprio celular).
 * A permissão fica salva: depois de concedida, funciona em segundo plano para sempre
 * (mesmo com Shizuku/Wi-Fi desligados), até desinstalar o app.
 */
object ShizukuHelper {
    const val PKG = "moe.shizuku.privileged.api"

    fun installed(c: Context) =
        try { c.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun running() = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted() =
        try { !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }
        catch (e: Throwable) { false }

    /** Roda "pm grant" como shell via Shizuku. Chamar fora da thread principal. */
    fun grantSelf(c: Context): Boolean {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
            m.isAccessible = true
            val cmd = arrayOf("pm", "grant", c.packageName, Touch.PERM)
            val proc = m.invoke(null, cmd, null, null) as Process
            proc.waitFor()
            Touch.canWrite(c)
        } catch (e: Throwable) {
            false
        }
    }
}

class ScriptApi(private val c: Context, private val h: Handler) {
    private val prefs = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    fun touches(on: Boolean) = Touch.set(c, "show_touches", on)
    fun pointer(on: Boolean) = Touch.set(c, "pointer_location", on)
    fun micPitch(st: Int) { prefs.edit().putInt("micPitch", st.coerceIn(-12, 12)).apply() }
    fun gamePitch(st: Int) { prefs.edit().putInt("gamePitch", st.coerceIn(-12, 12)).apply() }
    fun toast(m: String) { h.post { Toast.makeText(c, m, Toast.LENGTH_SHORT).show() } }
}
