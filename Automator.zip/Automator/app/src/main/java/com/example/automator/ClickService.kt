package com.example.automator
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ClickService : AccessibilityService() {
    companion object { @Volatile var inst: ClickService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Teclas de volume como gatilho: só "engole" a tecla se o script registrou onVolumeUp/onVolumeDown. */
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val en = Engine.current ?: return false
        val name = when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> "volup"
            KeyEvent.KEYCODE_VOLUME_DOWN -> "voldown"
            else -> return false
        }
        if (!en.has(name)) return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) en.fire(name)
        return true
    }

    private fun sw() = resources.displayMetrics.widthPixels
    private fun sh() = resources.displayMetrics.heightPixels
    fun screenW() = sw()
    fun screenH() = sh()
    private fun cx(v: Int) = v.coerceIn(0, (sw() - 1).coerceAtLeast(0))
    private fun cy(v: Int) = v.coerceIn(0, (sh() - 1).coerceAtLeast(0))

    fun click(x: Int, y: Int) {
        try {
            val p = Path().apply { moveTo(cx(x).toFloat(), cy(y).toFloat()) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
            dispatchGesture(g, null, null)
        } catch (_: Exception) {}
    }

    private fun gestureWait(g: GestureDescription, ms: Long) {
        try {
            val l = CountDownLatch(1)
            val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { l.countDown() }
                override fun onCancelled(d: GestureDescription?) { l.countDown() }
            }, null)
            if (ok) l.await(ms + 300, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) { throw e } catch (_: Exception) {}
    }

    private fun stroke(p: Path, ms: Long) = GestureDescription.StrokeDescription(p, 0, ms.coerceAtLeast(1L))

    /** Clique curtinho que espera o sistema terminar antes de voltar. Usado no spam. */
    fun clickWait(x: Int, y: Int) {
        val p = Path().apply { moveTo(cx(x).toFloat(), cy(y).toFloat()) }
        gestureWait(GestureDescription.Builder().addStroke(stroke(p, 8)).build(), 8)
    }

    fun swipeWait(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) {
        val p = Path().apply { moveTo(cx(x1).toFloat(), cy(y1).toFloat()); lineTo(cx(x2).toFloat(), cy(y2).toFloat()) }
        gestureWait(GestureDescription.Builder().addStroke(stroke(p, ms.toLong())).build(), ms.toLong())
    }

    fun holdWait(x: Int, y: Int, ms: Int) {
        val p = Path().apply { moveTo(cx(x).toFloat(), cy(y).toFloat()) }
        gestureWait(GestureDescription.Builder().addStroke(stroke(p, ms.toLong())).build(), ms.toLong())
    }

    /** Pinça com dois dedos: from/to = distância de cada dedo ao centro (to > from = zoom in). */
    fun pinchWait(x: Int, y: Int, from: Int, to: Int, ms: Int) {
        val a = Path().apply { moveTo(cx(x - from).toFloat(), cy(y).toFloat()); lineTo(cx(x - to).toFloat(), cy(y).toFloat()) }
        val b = Path().apply { moveTo(cx(x + from).toFloat(), cy(y).toFloat()); lineTo(cx(x + to).toFloat(), cy(y).toFloat()) }
        gestureWait(GestureDescription.Builder().addStroke(stroke(a, ms.toLong())).addStroke(stroke(b, ms.toLong())).build(), ms.toLong())
    }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun powerMenu() = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    fun lockScreen() = if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
    fun screenshotKey() = if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false

    // ---------- Leitura da tela ----------
    private fun roots(): List<AccessibilityNodeInfo> {
        val r = ArrayList<AccessibilityNodeInfo>()
        try { rootInActiveWindow?.let { r.add(it) } } catch (_: Exception) {}
        if (r.isEmpty()) {
            try { windows?.forEach { w -> w.root?.let { r.add(it) } } } catch (_: Exception) {}
        }
        return r
    }

    /** Todos os elementos que contêm o texto: (x, y, texto). */
    fun findAll(t: String): List<Triple<Int, Int, String>> {
        val out = ArrayList<Triple<Int, Int, String>>()
        for (r in roots()) {
            val ns = (try { r.findAccessibilityNodeInfosByText(t) } catch (_: Exception) { null }) ?: continue
            for (n in ns) {
                val b = Rect(); n.getBoundsInScreen(b)
                if (!b.isEmpty) out.add(Triple(b.centerX(), b.centerY(), (n.text ?: n.contentDescription ?: "").toString()))
            }
        }
        return out
    }

    /** Procura texto/descrição na tela e devolve o centro do elemento. */
    fun find(t: String): Point? = findAll(t).firstOrNull()?.let { Point(it.first, it.second) }

    /** Todo o texto visível na tela, uma linha por elemento. */
    fun screenText(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 60) return
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank() && n.isVisibleToUser) sb.append(t.trim()).append('\n')
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        for (r in roots()) walk(r, 0)
        return sb.toString().trim()
    }

    fun currentApp(): String = try { rootInActiveWindow?.packageName?.toString() ?: "" } catch (_: Exception) { "" }

    private fun focusedInput(): AccessibilityNodeInfo? {
        for (r in roots()) { val f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT); if (f != null) return f }
        return null
    }

    fun setText(t: String, append: Boolean): Boolean {
        val f = focusedInput() ?: return false
        val cur = if (append) (f.text?.toString() ?: "") else ""
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + t)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun paste(): Boolean = focusedInput()?.performAction(AccessibilityNodeInfo.ACTION_PASTE) ?: false

    // ---------- Screenshot / pixels (Android 11+) ----------
    fun shotBitmap(): Bitmap? {
        if (Build.VERSION.SDK_INT < 30) return null
        val l = CountDownLatch(1)
        var out: Bitmap? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = r.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                        out = bmp?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (_: Exception) {} finally { l.countDown() }
                }
                override fun onFailure(code: Int) { l.countDown() }
            })
            l.await(4, TimeUnit.SECONDS)
        } catch (e: InterruptedException) { throw e } catch (_: Exception) {}
        return out
    }
}
