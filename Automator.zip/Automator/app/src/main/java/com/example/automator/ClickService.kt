package com.example.automator
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class ClickService : AccessibilityService() {
    companion object { var inst: ClickService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Teclas de volume como gatilho: só "engole" a tecla se o script registrou onVolumeUp/onVolumeDown. */
    override fun onKeyEvent(e: KeyEvent): Boolean {
        val en = Engine.current ?: return false
        val name = when (e.keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> "volup"
            KeyEvent.KEYCODE_VOLUME_DOWN -> "voldown"
            else -> return false
        }
        if (!en.has(name)) return false
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) en.fire(name)
        return true
    }

    fun click(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
        dispatchGesture(g, null, null)
    }

    /** Clique curtinho (1 ms) que espera o sistema terminar antes de voltar. Usado no spam. */
    fun clickWait(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 8)).build()
        val l = java.util.concurrent.CountDownLatch(1)
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { l.countDown() }
            override fun onCancelled(d: GestureDescription?) { l.countDown() }
        }, null)
        if (ok) l.await(150, java.util.concurrent.TimeUnit.MILLISECONDS)
    }

    private fun runWait(p: Path, ms: Long) {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms.coerceAtLeast(1L))).build()
        val l = java.util.concurrent.CountDownLatch(1)
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { l.countDown() }
            override fun onCancelled(d: GestureDescription?) { l.countDown() }
        }, null)
        if (ok) l.await(ms + 300, java.util.concurrent.TimeUnit.MILLISECONDS)
    }

    fun swipeWait(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int) =
        runWait(Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }, ms.toLong())

    fun holdWait(x: Int, y: Int, ms: Int) =
        runWait(Path().apply { moveTo(x.toFloat(), y.toFloat()) }, ms.toLong())

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** Procura texto/descrição na tela e devolve o centro do elemento. */
    fun find(t: String): Point? {
        val root = rootInActiveWindow ?: return null
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            val b = Rect(); n.getBoundsInScreen(b)
            if (!b.isEmpty) return Point(b.centerX(), b.centerY())
        }
        return null
    }
}
