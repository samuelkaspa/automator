package com.example.automator
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent

class ClickService : AccessibilityService() {
    companion object { var inst: ClickService? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun click(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 20)).build()
        dispatchGesture(g, null, null)
    }

    /** Clique curtinho (1 ms) que espera o sistema terminar antes de voltar. Usado no spam. */
    fun clickWait(x: Int, y: Int) {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 1)).build()
        val l = java.util.concurrent.CountDownLatch(1)
        val ok = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { l.countDown() }
            override fun onCancelled(d: GestureDescription?) { l.countDown() }
        }, null)
        if (ok) l.await(150, java.util.concurrent.TimeUnit.MILLISECONDS)
    }

    /** Procura texto/descrição na tela e devolve o centro do elemento. */
    fun find(t: String): Point? {
        val root = rootInActiveWindow ?: return null
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            val b = Rect(); n.getBoundsInScreen(b)
            if (!b.isEmpty) return Point(b.centerX(), b.centerY())
        }
        return null
    }
}
