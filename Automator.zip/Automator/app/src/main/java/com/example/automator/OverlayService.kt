package com.example.automator
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var engine: Engine? = null
    private var code = ""
    private var dir = File("/nonexistent")
    private val imgs = mutableListOf<View>()
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private var layer: View? = null
    private var layerLp: WindowManager.LayoutParams? = null
    private var watching = false      // true enquanto o spam roda: camada deixa os cliques passarem e só "escuta"
    private var passThrough = false   // true por 150 ms ao repassar um toque simples
    private var watchStart = 0L
    private val bp by lazy { lp(dp(56), dp(56), 0x28).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) } }
    private var lang = "JavaScript"
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        code = i?.getStringExtra("code") ?: ""
        dir = File(i?.getStringExtra("dir") ?: "/nonexistent")
        lang = i?.getStringExtra("lang") ?: "JavaScript"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a", "Automator", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "a").setContentTitle("Automator rodando")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cleanup(); runScript(); buildBubble()
        Toast.makeText(this, "Automator ligado: procure a bolinha azul", Toast.LENGTH_LONG).show()
        return START_NOT_STICKY
    }

    private fun runScript() {
        engine?.stop()
        watching = false
        engine = Engine(this, dir, lang).also { e ->
            e.onError = { m -> ui.post { Toast.makeText(this, "Erro no script: $m", Toast.LENGTH_LONG).show() } }
            e.onArm = { ui.post { arm(true) } }
            e.onShow = { f, sec -> ui.post { showImg(f, sec) } }
            e.onSpam = { on -> ui.post { setWatching(on) } }
            e.onPass = { on -> ui.post { passThrough = on; applyFlags() } }
            e.start(code)
        }
    }

    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "●"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC3366FF.toInt()) }
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false; var longP = false
        val lpRun = Runnable { longP = true; toggleMenu() }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bp.x; sy = bp.y; dx = e.rawX; dy = e.rawY; moved = false; longP = false; ui.postDelayed(lpRun, 500) }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) { moved = true; ui.removeCallbacks(lpRun) }
                    bp.x = sx + mx; bp.y = sy + my; wm.updateViewLayout(b, bp)
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(lpRun)
                    if (!moved && !longP) { if (engine?.has("bubble") == true) engine?.fire("bubble") else toggleMenu() }
                }
            }
            true
        }
        bubble = b; wm.addView(b, bp)
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        fun item(t: String, a: () -> Unit) = m.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { closeMenu(); a() }
        })
        item("Bolinha invisível/visível") { bubble?.alpha = if (bubble?.alpha == 1f) 0.08f else 1f }
        item(if (engine?.paused == true) "Continuar" else "Pausar") { engine?.let { it.paused = !it.paused } }
        item("Resetar") { runScript() }
        item(if (layer == null) "Gatilho de toque (experimental): ligar" else "Gatilho de toque (experimental): desligar") { arm(layer == null) }
        item("Parar e fechar") { engine?.stop(); stopSelf() }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0x28)
            .apply { gravity = Gravity.TOP or Gravity.START; x = bp.x + dp(60); y = bp.y }
        menu = m; wm.addView(m, p)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    private fun applyFlags() {
        val v = layer ?: return; val p = layerLp ?: return
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (watching) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        else if (passThrough) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        p.flags = f
        try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
    }

    private fun setWatching(on: Boolean) {
        watching = on; watchStart = SystemClock.uptimeMillis(); applyFlags()
    }

    /**
     * Camada de tela cheia (invisível).
     * Parada: 2 dedos -> onTwoFingers; 1 toque ou segurar 1 dedo -> onOneFinger; toque simples é repassado como clique.
     * Durante o spam: a camada vira "só escuta": os cliques passam para o app de baixo e qualquer toque real
     * (aparece como ACTION_OUTSIDE) chama onOneFinger.
     */
    private fun arm(on: Boolean) {
        engine?.armed = on
        if (on == (layer != null)) return
        val b = bubble
        if (b != null) try { wm.removeView(b) } catch (_: Exception) {}
        if (on) {
            val v = View(this)
            val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
            var multi = false; var held = false; var dX = 0; var dY = 0
            val holdRun = Runnable { held = true; engine?.let { it.tx = dX; it.ty = dY; it.kind = "hold" }; engine?.fireOne() }
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_OUTSIDE ->
                        // deviceId 0 = toque injetado pelo próprio app; só toque real para o spam
                        if (watching && e.deviceId != 0 && SystemClock.uptimeMillis() - watchStart > 600) { engine?.kind = "outside"; engine?.fireOne() }
                    MotionEvent.ACTION_DOWN -> {
                        multi = false; held = false; dX = e.rawX.toInt(); dY = e.rawY.toInt()
                        trk.clear(); track(e, 0)
                        ui.postDelayed(holdRun, 500)
                    }
                    MotionEvent.ACTION_POINTER_DOWN -> {
                        track(e, e.actionIndex)
                        if (e.pointerCount == 2) {
                            ui.removeCallbacks(holdRun); multi = true
                            engine?.tx = ((e.getX(0) + e.getX(1)) / 2).toInt()
                            engine?.ty = ((e.getY(0) + e.getY(1)) / 2).toInt()
                            engine?.kind = "two"
                            engine?.fire()
                        }
                    }
                    MotionEvent.ACTION_MOVE -> move(e)
                    MotionEvent.ACTION_POINTER_UP -> { move(e); trk[e.getPointerId(e.actionIndex)]?.t1 = e.eventTime }
                    MotionEvent.ACTION_CANCEL -> { ui.removeCallbacks(holdRun); trk.clear() }
                    MotionEvent.ACTION_UP -> {
                        ui.removeCallbacks(holdRun)
                        move(e); trk[e.getPointerId(e.actionIndex)]?.t1 = e.eventTime
                        if (!multi && !held) {
                            engine?.let { it.tx = e.rawX.toInt(); it.ty = e.rawY.toInt(); it.kind = "tap" }
                            engine?.fireOne()
                        }
                        forward()   // todo toque (toque, segurar, arrastar, 2 dedos) segue pra tela
                    }
                }
                true
            }
            layer = v; layerLp = p; wm.addView(v, p)
            applyFlags()
        } else { layer?.let { try { wm.removeView(it) } catch (_: Exception) {} }; layer = null; watching = false }
        if (b != null) wm.addView(b, bp)
    }

    // ---- Todo toque passa pela camada (e pelo onTouch do script) e depois vai pra tela ----
    private class Trk(val t0: Long, val x0: Float, val y0: Float) {
        val path = Path().apply { moveTo(x0, y0) }
        var t1 = t0; var xl = x0; var yl = y0; var far = 0f
    }
    private val trk = LinkedHashMap<Int, Trk>()

    private fun px(e: MotionEvent, i: Int) = e.getX(i) + (e.rawX - e.getX(0))
    private fun py(e: MotionEvent, i: Int) = e.getY(i) + (e.rawY - e.getY(0))
    private fun track(e: MotionEvent, i: Int) { trk[e.getPointerId(i)] = Trk(e.eventTime, px(e, i), py(e, i)) }
    private fun move(e: MotionEvent) {
        for (i in 0 until e.pointerCount) {
            val t = trk[e.getPointerId(i)] ?: continue
            val x = px(e, i); val y = py(e, i)
            if (abs(x - t.xl) < 2f && abs(y - t.yl) < 2f) continue
            t.path.lineTo(x, y); t.xl = x; t.yl = y; t.t1 = e.eventTime
            t.far = maxOf(t.far, abs(x - t.x0) + abs(y - t.y0))
        }
    }

    private class Raw(val x0: Float, val y0: Float, val path: Path, val dur: Long)
    private class Out(val g: GestureDescription, val at: Long)
    private val outQ = ArrayList<Out>()
    private var outBusy = false
    private val conv = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun build(l: List<GestureDescription.StrokeDescription>): GestureDescription =
        GestureDescription.Builder().apply { l.forEach { addStroke(it) } }.build()

    /** Reenvia o gesto que acabou de terminar. Toque rápido vai com 20 ms; arrastar/segurar mantém o tempo real. */
    private fun forward() {
        if (trk.isEmpty()) return
        val raws = ArrayList<Raw>()
        for (t in trk.values.take(10)) {
            var dur = (t.t1 - t.t0).coerceIn(1L, 60000L)
            val path: Path
            if (t.far < 24f && dur <= 400L) { path = Path().apply { moveTo(t.x0, t.y0) }; dur = 20L }
            else { path = t.path; if (dur < 20L) dur = 20L }
            raws.add(Raw(t.x0, t.y0, path, dur))
        }
        trk.clear()
        val en = engine
        if (en != null && en.has("touch")) {
            // o script roda fora da tela principal: nunca trava o celular, e tem limite de tempo
            conv.execute {
                val strokes = ArrayList<GestureDescription.StrokeDescription>()
                var delay = 0L
                for (r in raws) {
                    val res = en.convert(r.x0.toInt(), r.y0.toInt()) ?: continue   // blockTouch() = não vai pra tela
                    delay = maxOf(delay, en.delayMs)
                    val dx = res[0] - r.x0; val dy = res[1] - r.y0
                    if (dx != 0f || dy != 0f) r.path.offset(dx, dy)
                    strokes.add(GestureDescription.StrokeDescription(r.path, 0, r.dur))
                }
                if (strokes.isNotEmpty()) { val g = build(strokes); ui.post { enqueue(g, delay) } }
            }
        } else {
            enqueue(build(raws.map { GestureDescription.StrokeDescription(it.path, 0, it.dur) }), 0L)
        }
    }

    /** Fila: um gesto por vez, na ordem; delayTouch(ms) atrasa só aquele toque. */
    private fun enqueue(g: GestureDescription, delay: Long) {
        outQ.add(Out(g, SystemClock.uptimeMillis() + delay)); pump()
    }

    private fun pump() {
        if (outBusy) return
        val o = outQ.firstOrNull() ?: return
        outBusy = true
        val wait = (o.at - SystemClock.uptimeMillis()).coerceAtLeast(0L)
        ui.postDelayed({
            passThrough = true; applyFlags()          // camada deixa de ser tocável
            ui.postDelayed({                          // ~1 frame pro sistema aplicar
                val done = {
                    if (outQ.isNotEmpty()) outQ.removeAt(0)
                    passThrough = false; applyFlags(); outBusy = false; pump()
                }
                val ok = ClickService.inst?.dispatchGesture(o.g, object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(d: GestureDescription?) { done() }
                    override fun onCancelled(d: GestureDescription?) { done() }
                }, null) ?: false
                if (!ok) done()
            }, 20)
        }, wait)
    }

    private fun showImg(f: File, sec: Int) {
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 }) ?: return
        val v = ImageView(this).apply { setImageBitmap(bmp) }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply { gravity = Gravity.CENTER }
        wm.addView(v, p); imgs.add(v)
        ui.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {}; imgs.remove(v) }, sec * 1000L)
    }

    private fun cleanup() {
        imgs.toList().forEach { try { wm.removeView(it) } catch (_: Exception) {} }; imgs.clear()
        closeMenu()
        listOf(bubble, layer).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        bubble = null; layer = null; watching = false
        outQ.clear(); outBusy = false; passThrough = false; trk.clear()
    }

    override fun onDestroy() { engine?.stop(); ui.removeCallbacksAndMessages(null); conv.shutdownNow(); if (::wm.isInitialized) cleanup(); super.onDestroy() }
}
