package com.example.automator
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var engine: Engine? = null
    private var code = ""
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private var layer: View? = null
    private var layerLp: WindowManager.LayoutParams? = null
    private val bp = lp(dp(56), dp(56), 0x28).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) }
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        code = i?.getStringExtra("code") ?: ""
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a", "Automator", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "a").setContentTitle("Automator rodando")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cleanup(); runScript(); buildBubble()
        return START_NOT_STICKY
    }

    private fun runScript() {
        engine?.stop()
        engine = Engine(this).also { e ->
            e.onArm = { ui.post { arm(true) } }
            e.start(code)
        }
    }

    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "●"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC3366FF.toInt()) }
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bp.x; sy = bp.y; dx = e.rawX; dy = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    bp.x = sx + mx; bp.y = sy + my; wm.updateViewLayout(b, bp)
                }
                MotionEvent.ACTION_UP -> if (!moved) toggleMenu()
            }
            true
        }
        bubble = b; wm.addView(b, bp)
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        fun item(t: String, a: () -> Unit) = m.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { closeMenu(); a() }
        })
        item("Bolinha invisível/visível") { bubble?.alpha = if (bubble?.alpha == 1f) 0.08f else 1f }
        item(if (engine?.paused == true) "Continuar" else "Pausar") { engine?.let { it.paused = !it.paused } }
        item("Resetar") { runScript() }
        item(if (layer == null) "Gatilho 2 dedos: ligar" else "Gatilho 2 dedos: desligar") { arm(layer == null) }
        item("Parar e fechar") { engine?.stop(); stopSelf() }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0x28)
            .apply { gravity = Gravity.TOP or Gravity.START; x = bp.x + dp(60); y = bp.y }
        menu = m; wm.addView(m, p)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    /** Camada de tela cheia que enxerga toques. 2 dedos = dispara; 1 toque é repassado como clique. */
    private fun arm(on: Boolean) {
        if (on == (layer != null)) return
        val b = bubble
        if (b != null) try { wm.removeView(b) } catch (_: Exception) {}
        if (on) {
            val v = View(this)
            val p = lp(-1, -1, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN)
            var multi = false
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> multi = false
                    MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) { multi = true; engine?.fire() }
                    MotionEvent.ACTION_UP -> if (!multi) {
                        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; wm.updateViewLayout(v, p)
                        ClickService.inst?.click(e.rawX.toInt(), e.rawY.toInt())
                        v.postDelayed({ p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv(); try { wm.updateViewLayout(v, p) } catch (_: Exception) {} }, 150)
                    }
                }
                true
            }
            layer = v; layerLp = p; wm.addView(v, p)
        } else { layer?.let { try { wm.removeView(it) } catch (_: Exception) {} }; layer = null }
        if (b != null) wm.addView(b, bp)
    }

    private fun cleanup() {
        closeMenu()
        listOf(bubble, layer).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        bubble = null; layer = null
    }

    override fun onDestroy() { engine?.stop(); if (::wm.isInitialized) cleanup(); super.onDestroy() }
}
