package com.example.automator
import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs

/**
 * Só a bolinha (e o menu dela) recebem toque. Nada cobre a tela:
 * os seus toques vão direto pro jogo/app, sem passar pelo Automator.
 * O app só mexe na tela quando o SCRIPT manda (click, spam, swipe...).
 * Scripts HTML rodam numa janelinha flutuante (arrastável, pode ocultar) que continua viva em segundo plano.
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var engine: Engine? = null
    private var code = ""
    private var dir = File("/nonexistent")
    private val imgs = mutableListOf<View>()
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var webView: WebView? = null
    private var panelP: WindowManager.LayoutParams? = null
    private var panelHidden = false
    private val bp by lazy { lp(dp(56), dp(56), 0x28).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) } }
    private var lang = "JavaScript"
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        code = i?.getStringExtra("code") ?: ""
        dir = File(i?.getStringExtra("dir") ?: "/nonexistent")
        lang = i?.getStringExtra("lang") ?: "JavaScript"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a", "Automator", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "a").setContentTitle("Automator rodando")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, n)
        } catch (e: Exception) {
            Toast.makeText(this, "Não consegui iniciar em segundo plano: ${e.message}", Toast.LENGTH_LONG).show()
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            cleanup(); runScript(); buildBubble()
            Toast.makeText(this, "Automator ligado: procure a bolinha azul", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao iniciar: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun runScript() {
        engine?.stop()
        closePanel()
        val e = Engine(this, dir, lang)
        engine = e
        e.onError = { m -> ui.post { Toast.makeText(this, "Erro no script: $m", Toast.LENGTH_LONG).show() } }
        e.onShow = { f, sec -> ui.post { showImg(f, sec) } }
        e.onText = { t, sec -> ui.post { showText(t, sec) } }
        e.onQuit = { ui.post { engine?.stop(); stopSelf() } }
        if (lang == "HTML") {
            e.onHtml = { html -> ui.post { openPanel(e, html) } }
        }
        e.start(code)
    }

    // ---------- Janela HTML ----------
    private fun withPrelude(src: String): String {
        val pre = "<script>" + Engine.preWeb() + "</script>"
        var body = src
        if (!body.contains("<")) body = "<script>$body</script>"   // só JS colado: roda mesmo assim
        val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(body)
            ?: Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(body)
        return if (head != null) body.substring(0, head.range.last + 1) + pre + body.substring(head.range.last + 1) else pre + body
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun openPanel(e: Engine, html: String) {
        if (engine !== e) return
        closePanel()
        val wv = WebView(this)
        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            try { allowUniversalAccessFromFileURLs = true } catch (_: Throwable) {}
        }
        wv.setBackgroundColor(Color.WHITE)
        wv.webViewClient = WebViewClient()
        wv.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(r: PermissionRequest?) { try { r?.grant(r.resources) } catch (_: Exception) {} }
        }
        wv.addJavascriptInterface(e.WebApi(), "api")
        e.onWeb = { js -> ui.post { try { wv.evaluateJavascript(js, null) } catch (_: Exception) {} } }
        e.onWin = { cmd, a, b, c, d -> ui.post { winCmd(cmd, a, b, c, d) } }

        val bar = TextView(this).apply {
            text = "⠿ HTML — arraste aqui   ✕ ocultar"; setTextColor(Color.WHITE); textSize = 13f
            setBackgroundColor(0xEE3366FF.toInt()); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        box.addView(bar, LinearLayout.LayoutParams(-1, -2))
        box.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))

        val dm = resources.displayMetrics
        val p = lp((dm.widthPixels * 0.9).toInt(), (dm.heightPixels * 0.45).toInt(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or 0x01000000)
            .apply { gravity = Gravity.TOP or Gravity.START; x = (dm.widthPixels * 0.05).toInt(); y = dp(90) }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false
        bar.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; dx = ev.rawX; dy = ev.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (ev.rawX - dx).toInt(); val my = (ev.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) moved = true
                    if (moved) { p.x = sx + mx; p.y = sy + my; try { wm.updateViewLayout(box, p) } catch (_: Exception) {} }
                }
                MotionEvent.ACTION_UP -> if (!moved && ev.x > bar.width - dp(80)) winCmd("hide", 0, 0, 0, 0)
            }
            true
        }
        panel = box; webView = wv; panelP = p; panelHidden = false
        wm.addView(box, p)
        wv.loadDataWithBaseURL("file://" + dir.absolutePath + "/", withPrelude(html), "text/html", "utf-8", null)
    }

    private fun winCmd(cmd: String, a: Int, b: Int, c: Int, d: Int) {
        val box = panel ?: return
        val p = panelP ?: return
        val dm = resources.displayMetrics
        when (cmd) {
            "hide" -> {
                panelHidden = true
                p.width = 1; p.height = 1; p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                box.alpha = 0f
            }
            "show" -> {
                panelHidden = false
                p.width = (dm.widthPixels * 0.9).toInt(); p.height = (dm.heightPixels * 0.45).toInt()
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                box.alpha = 1f
            }
            "geom" -> {
                p.x = a; p.y = b
                if (c > 0) p.width = c
                if (d > 0) p.height = d
            }
            "focus1" -> { p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv(); p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
            "focus0" -> p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        try { wm.updateViewLayout(box, p) } catch (_: Exception) {}
    }

    private fun closePanel() {
        engine?.onWeb = null; engine?.onWin = null
        webView?.let { try { it.stopLoading(); it.loadUrl("about:blank"); it.removeJavascriptInterface("api"); it.destroy() } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        webView = null; panel = null; panelP = null
    }

    // ---------- Bolinha ----------
    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "●"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC3366FF.toInt()) }
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false; var longP = false
        val lpRun = Runnable { longP = true; toggleMenu() }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bp.x; sy = bp.y; dx = e.rawX; dy = e.rawY; moved = false; longP = false; ui.postDelayed(lpRun, 500) }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) { moved = true; ui.removeCallbacks(lpRun) }
                    bp.x = sx + mx; bp.y = sy + my
                    try { wm.updateViewLayout(b, bp) } catch (_: Exception) {}
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(lpRun)
                    if (!moved && !longP) { if (engine?.has("bubble") == true) engine?.fire("bubble") else toggleMenu() }
                }
            }
            true
        }
        bubble = b; wm.addView(b, bp)
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        fun item(t: String, a: () -> Unit) = m.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { closeMenu(); a() }
        })
        item("Bolinha invisível/visível") { bubble?.alpha = if (bubble?.alpha == 1f) 0.08f else 1f }
        if (lang == "HTML") item(if (panelHidden) "Mostrar janela HTML" else "Ocultar janela HTML") { winCmd(if (panelHidden) "show" else "hide", 0, 0, 0, 0) }
        item(if (engine?.paused == true) "Continuar" else "Pausar") { engine?.let { it.paused = !it.paused } }
        item("Resetar") { runScript() }
        item("Parar e fechar") { engine?.stop(); stopSelf() }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0x28)
            .apply { gravity = Gravity.TOP or Gravity.START; x = bp.x + dp(60); y = bp.y }
        menu = m; wm.addView(m, p)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    /** Só mostra; nunca recebe toque (FLAG_NOT_TOUCHABLE). */
    private fun addInfo(v: View, g: Int, sec: Int) {
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply {
            gravity = g; if (g != Gravity.CENTER) y = dp(80)
        }
        try { wm.addView(v, p) } catch (_: Exception) { return }
        imgs.add(v)
        ui.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {}; imgs.remove(v) }, sec.coerceAtLeast(1) * 1000L)
    }

    private fun showImg(f: File, sec: Int) {
        val bmp = (try { BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 }) } catch (_: Throwable) { null }) ?: return
        addInfo(ImageView(this).apply { setImageBitmap(bmp) }, Gravity.CENTER, sec)
    }

    private fun showText(t: String, sec: Int) {
        val v = TextView(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xCC000000.toInt()) }
        }
        addInfo(v, Gravity.TOP or Gravity.CENTER_HORIZONTAL, sec)
    }

    private fun cleanup() {
        imgs.toList().forEach { try { wm.removeView(it) } catch (_: Exception) {} }; imgs.clear()
        closeMenu(); closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    override fun onDestroy() {
        engine?.stop(); ui.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) cleanup()
        super.onDestroy()
    }
}
