package com.example.automator
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.*
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs

/**
 * Só a bolinha (e o menu dela) recebem toque. Nada cobre a tela:
 * os seus toques vão direto pro jogo/app, sem passar pelo Automator.
 * O app só mexe na tela quando o SCRIPT manda (click, spam, swipe...).
 */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var engine: Engine? = null
    private var code = ""
    private var dir = File("/nonexistent")
    private val imgs = mutableListOf<View>()
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private val bp by lazy { lp(dp(56), dp(56), 0x28).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(200) } }
    private var lang = "JavaScript"
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        code = i?.getStringExtra("code") ?: ""
        dir = File(i?.getStringExtra("dir") ?: "/nonexistent")
        lang = i?.getStringExtra("lang") ?: "JavaScript"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("a", "Automator", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "a").setContentTitle("Automator rodando")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        cleanup(); runScript(); buildBubble()
        Toast.makeText(this, "Automator ligado: procure a bolinha azul", Toast.LENGTH_LONG).show()
        return START_NOT_STICKY
    }

    private fun runScript() {
        engine?.stop()
        engine = Engine(this, dir, lang).also { e ->
            e.onError = { m -> ui.post { Toast.makeText(this, "Erro no script: $m", Toast.LENGTH_LONG).show() } }
            e.onShow = { f, sec -> ui.post { showImg(f, sec) } }
            e.onText = { t, sec -> ui.post { showText(t, sec) } }
            e.start(code)
        }
    }

    private fun buildBubble() {
        val b = TextView(this).apply {
            text = "●"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCC3366FF.toInt()) }
        }
        var sx = 0; var sy = 0; var dx = 0f; var dy = 0f; var moved = false; var longP = false
        val lpRun = Runnable { longP = true; toggleMenu() }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = bp.x; sy = bp.y; dx = e.rawX; dy = e.rawY; moved = false; longP = false; ui.postDelayed(lpRun, 500) }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                    if (abs(mx) > 10 || abs(my) > 10) { moved = true; ui.removeCallbacks(lpRun) }
                    bp.x = sx + mx; bp.y = sy + my; wm.updateViewLayout(b, bp)
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(lpRun)
                    if (!moved && !longP) { if (engine?.has("bubble") == true) engine?.fire("bubble") else toggleMenu() }
                }
            }
            true
        }
        bubble = b; wm.addView(b, bp)
    }

    private fun toggleMenu() {
        if (menu != null) { closeMenu(); return }
        val m = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        fun item(t: String, a: () -> Unit) = m.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { closeMenu(); a() }
        })
        item("Bolinha invisível/visível") { bubble?.alpha = if (bubble?.alpha == 1f) 0.08f else 1f }
        item(if (engine?.paused == true) "Continuar" else "Pausar") { engine?.let { it.paused = !it.paused } }
        item("Resetar") { runScript() }
        item("Parar e fechar") { engine?.stop(); stopSelf() }
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, 0x28)
            .apply { gravity = Gravity.TOP or Gravity.START; x = bp.x + dp(60); y = bp.y }
        menu = m; wm.addView(m, p)
    }

    private fun closeMenu() { menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }; menu = null }

    /** Só mostra; nunca recebe toque (FLAG_NOT_TOUCHABLE). */
    private fun addInfo(v: View, g: Int, sec: Int) {
        val p = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply {
            gravity = g; if (g != Gravity.CENTER) y = dp(80)
        }
        wm.addView(v, p); imgs.add(v)
        ui.postDelayed({ try { wm.removeView(v) } catch (_: Exception) {}; imgs.remove(v) }, sec * 1000L)
    }

    private fun showImg(f: File, sec: Int) {
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 }) ?: return
        addInfo(ImageView(this).apply { setImageBitmap(bmp) }, Gravity.CENTER, sec)
    }

    private fun showText(t: String, sec: Int) {
        val v = TextView(this).apply {
            text = t; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xCC000000.toInt()) }
        }
        addInfo(v, Gravity.TOP or Gravity.CENTER_HORIZONTAL, sec)
    }

    private fun cleanup() {
        imgs.toList().forEach { try { wm.removeView(it) } catch (_: Exception) {} }; imgs.clear()
        closeMenu()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
    }

    override fun onDestroy() { engine?.stop(); ui.removeCallbacksAndMessages(null); if (::wm.isInitialized) cleanup(); super.onDestroy() }
}
