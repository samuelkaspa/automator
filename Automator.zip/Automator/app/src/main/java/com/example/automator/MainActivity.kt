package com.example.automator
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var list = mutableListOf<Pair<String, String>>()
    private lateinit var lv: ListView

    private val template = """// Tocar com 2 dedos liga/desliga o spam de cliques
var on = false;
onTwoFingers(function () {
  on = !on;
  if (on) spam(540, 1200, 60); else stopSpam();
});

// Exemplo: se aparecer "WhatsApp" na tela, toca nele
// while (true) { clickText("WhatsApp"); sleep(1000); }
// Voz: speak("Olá");  |  Chave salva: getKey()
"""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = "Automator"; textSize = 26f })
        root.addView(Button(this).apply { text = "Conferir permissões"; setOnClickListener { checkPerms(true) } })
        val key = EditText(this).apply { hint = "Chave de API (opcional)"; setText(Store.key(this@MainActivity)); setSingleLine() }
        root.addView(key)
        root.addView(Button(this).apply { text = "Salvar chave"; setOnClickListener { Store.setKey(context, key.text.toString()); toast("Chave salva") } })
        lv = ListView(this)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "+"; textSize = 24f; setOnClickListener { editor(-1) } })
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> editor(i) }
        lv.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setMessage("Apagar \"${list[i].first}\"?")
                .setPositiveButton("Apagar") { _, _ -> list.removeAt(i); Store.save(this, list); refresh() }
                .setNegativeButton("Cancelar", null).show(); true }
        refresh()
    }

    private fun refresh() {
        list = Store.scripts(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list.map { it.first })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun checkPerms(showOk: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (!Settings.canDrawOverlays(this)) {
            toast("Ative \"Exibir sobre outros apps\" para o Automator")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return false
        }
        if (ClickService.inst == null) {
            toast("Ative o Automator em Acessibilidade")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return false
        }
        if (showOk) toast("Tudo liberado ✅"); return true
    }

    private fun editor(idx: Int) {
        val ctx = this
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0) }
        val lang = Spinner(ctx).apply { adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, arrayOf("JavaScript")) }
        val name = EditText(ctx).apply { hint = "Nome"; setSingleLine(); if (idx >= 0) setText(list[idx].first) }
        val code = EditText(ctx).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; minLines = 12; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(if (idx >= 0) list[idx].second else template)
        }
        box.addView(lang); box.addView(name); box.addView(code)
        fun save() {
            val n = name.text.toString().ifBlank { "Script ${list.size + 1}" }
            if (idx >= 0) list[idx] = n to code.text.toString() else list.add(n to code.text.toString())
            Store.save(ctx, list); refresh()
        }
        AlertDialog.Builder(ctx).setView(ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("Começar") { _, _ ->
                save()
                if (checkPerms(false)) {
                    startForegroundService(Intent(ctx, OverlayService::class.java).putExtra("code", code.text.toString()))
                    moveTaskToBack(true)
                }
            }
            .setNeutralButton("Salvar") { _, _ -> save() }
            .setNegativeButton("Cancelar", null).show()
    }
}
