package com.example.automator
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private var list = mutableListOf<Pair<String, String>>()
    private lateinit var lv: ListView
    private var pendingDir: File? = null

    private val langs = arrayOf("JavaScript", "Lua")

    private val jsTemplate = """// 2 dedos: começa a spamar no ponto tocado. 1 toque ou segurar 1 dedo: para.
var on = false;
onTwoFingers(function () {
  if (on) return;
  on = true;
  spam(touchX(), touchY(), 10);
});
onOneFinger(function () {
  if (!on) return;
  on = false;
  stopSpam();
});

// Exemplo: se aparecer "Play Store" na tela, toca nele
// while (true) { clickText("Play Store"); sleep(1000); }
// Outras funções: files() playAudio("a.mp3") stopAudio() showImage("f.jpg",5) speak("Oi") getKey()
"""

    private val luaTemplate = """-- 2 dedos: começa a spamar no ponto tocado. 1 toque ou segurar 1 dedo: para.
local on = false
onTwoFingers(function()
  if on then return end
  on = true
  spam(touchX(), touchY(), 10)
end)
onOneFinger(function()
  if not on then return end
  on = false
  stopSpam()
end)

-- Exemplo: se aparecer "Play Store" na tela, toca nele
-- while true do clickText("Play Store") sleep(1000) end
-- Outras funções: files() playAudio("a.mp3") stopAudio() showImage("f.jpg",5) speak("Oi") getKey()
"""

    private fun dir(n: String) = File(filesDir, "proj/" + n.replace(Regex("[^A-Za-z0-9_-]"), "_"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = "Automator"; textSize = 26f })
        root.addView(Button(this).apply { text = "Conferir permissões"; setOnClickListener { checkPerms(true) } })
        val key = EditText(this).apply { hint = "Chave de API (opcional)"; setText(Store.key(this@MainActivity)); setSingleLine() }
        root.addView(key)
        root.addView(Button(this).apply { text = "Salvar chave"; setOnClickListener { Store.setKey(context, key.text.toString()); toast("Chave salva") } })
        lv = ListView(this)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "+"; textSize = 24f; setOnClickListener { editor(-1) } })
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> editor(i) }
        lv.setOnItemLongClickListener { _, _, i, _ -> confirmDelete(i) { refresh() }; true }
        refresh()
    }

    private fun refresh() {
        list = Store.scripts(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list.map { it.first })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun confirmDelete(i: Int, done: () -> Unit) {
        AlertDialog.Builder(this).setMessage("Apagar \"${list[i].first}\" e todos os arquivos dele?")
            .setPositiveButton("Apagar") { _, _ ->
                dir(list[i].first).deleteRecursively(); Store.delLang(this, list[i].first)
                list.removeAt(i); Store.save(this, list); done()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun accessibilityOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        .orEmpty().contains(packageName)

    private fun checkPerms(showOk: Boolean): Boolean {
        val ps = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) ps.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = ps.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        if (!Settings.canDrawOverlays(this)) {
            toast("Ative \"Exibir sobre outros apps\" para o Automator")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return false
        }
        if (!accessibilityOn()) {
            toast("Ative o Automator em Acessibilidade")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return false
        }
        if (showOk) toast("Tudo liberado ✅"); return true
    }

    private fun editor(idx: Int) {
        val ctx = this
        var cur = idx
        val oldName = if (idx >= 0) list[idx].first else null
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0) }
        val lang = Spinner(ctx).apply {
            adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, langs)
            if (idx >= 0) setSelection(langs.indexOf(Store.lang(ctx, list[idx].first)).coerceAtLeast(0))
        }
        val name = EditText(ctx).apply { hint = "Nome"; setSingleLine(); if (idx >= 0) setText(list[idx].first) }
        val code = EditText(ctx).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; minLines = 10; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(if (idx >= 0) list[idx].second else jsTemplate)
        }
        lang.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val t = code.text.toString()
                if (t.isBlank() || t == jsTemplate || t == luaTemplate) code.setText(if (pos == 1) luaTemplate else jsTemplate)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun save(): File {
            val n = name.text.toString().ifBlank { "Script ${list.size + 1}" }
            if (cur >= 0) {
                val od = dir(list[cur].first); val nd = dir(n)
                if (list[cur].first != n && od.exists() && !nd.exists()) od.renameTo(nd)
                list[cur] = n to code.text.toString()
            } else { list.add(n to code.text.toString()); cur = list.lastIndex }
            Store.setLang(ctx, n, lang.selectedItem.toString())
            if (oldName != null && oldName != n) Store.delLang(ctx, oldName)
            Store.save(ctx, list); refresh()
            return dir(n)
        }
        val attach = Button(ctx).apply {
            text = "📎 Anexar som / música / vídeo / foto"; isAllCaps = false
            setOnClickListener {
                pendingDir = save()
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*", "image/*"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 7)
            }
        }
        val manage = Button(ctx).apply {
            text = "Ver / remover anexos"; isAllCaps = false
            setOnClickListener {
                val d = save(); val names = d.list()?.sorted()?.toTypedArray() ?: emptyArray()
                if (names.isEmpty()) { toast("Nenhum anexo"); return@setOnClickListener }
                AlertDialog.Builder(ctx).setTitle("Toque para remover")
                    .setItems(names) { _, i -> File(d, names[i]).delete(); toast("Removido: ${names[i]}") }
                    .setNegativeButton("Fechar", null).show()
            }
        }
        box.addView(lang); box.addView(name); box.addView(attach); box.addView(manage); box.addView(code)
        val dlg = AlertDialog.Builder(ctx).setView(ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("Começar") { _, _ ->
                val d = save()
                if (checkPerms(false)) {
                    startForegroundService(Intent(ctx, OverlayService::class.java)
                        .putExtra("code", code.text.toString()).putExtra("dir", d.absolutePath)
                        .putExtra("lang", lang.selectedItem.toString()))
                    moveTaskToBack(true)
                }
            }
            .setNeutralButton("Salvar") { _, _ -> save() }
        if (idx >= 0) dlg.setNegativeButton("Apagar") { _, _ -> confirmDelete(cur) { refresh() } }
        else dlg.setNegativeButton("Cancelar", null)
        dlg.show()
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != 7 || c != RESULT_OK || d == null) return
        val target = pendingDir ?: return
        target.mkdirs()
        val uris = LinkedHashSet<Uri>()
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        d.data?.let { uris.add(it) }
        toast("Copiando arquivos…")
        Thread {
            var n = 0
            for (u in uris) {
                try {
                    val nm = contentResolver.query(u, null, null, null, null)?.use {
                        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                    } ?: "arquivo$n"
                    contentResolver.openInputStream(u)?.use { i -> File(target, nm).outputStream().use { o -> i.copyTo(o) } }
                    n++
                } catch (_: Exception) {}
            }
            runOnUiThread { toast("$n arquivo(s) adicionado(s)") }
        }.start()
    }
}
