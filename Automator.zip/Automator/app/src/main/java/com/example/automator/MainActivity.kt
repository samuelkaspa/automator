package com.example.automator
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private var list = mutableListOf<Pair<String, String>>()
    private lateinit var lv: ListView
    private var pendingDir: File? = null

    private val langs = arrayOf("JavaScript", "Lua", "HTML")

    private val jsTemplate = """// GATILHOS: onVolumeUp(fn)  onVolumeDown(fn)  onBubble(fn)
// (onBubble = toque curto na bolinha; segurar a bolinha abre o menu)
// Volume+ liga/desliga o spam, Volume- para. Troque X e Y pelo ponto que quer clicar.
var X = 540, Y = 1200, on = false;
onVolumeUp(function () {
  on = !on;
  if (on) spam(X, Y, 20); else stopSpam();
});
onVolumeDown(function () { on = false; stopSpam(); });

// Também: swipe  hold  doubleClick  scroll("down")  back  home  recents  showText  speak  readScreen  ai("pergunta")  openApp("nome")
// Toque em "Ajuda: todos os comandos" na tela inicial para ver a lista completa.

// Gatilho pela tela: quando o texto aparecer, faz as ações
// while (true) {
//   if (findText("Play Store")) { clickText("Play Store"); sleep(2000); }
//   sleep(500);
// }
"""

    private val luaTemplate = """-- GATILHOS: onVolumeUp(fn)  onVolumeDown(fn)  onBubble(fn)
-- (onBubble = toque curto na bolinha; segurar a bolinha abre o menu)
-- Volume+ liga/desliga o spam, Volume- para. Troque X e Y pelo ponto que quer clicar.
local X, Y, on = 540, 1200, false
onVolumeUp(function()
  on = not on
  if on then spam(X, Y, 20) else stopSpam() end
end)
onVolumeDown(function() on = false stopSpam() end)

-- Também: swipe  hold  doubleClick  scroll("down")  back  home  recents  showText  speak  readScreen  ai("pergunta")  openApp("nome")
-- Toque em "Ajuda: todos os comandos" na tela inicial para ver a lista completa.

-- Gatilho pela tela: quando o texto aparecer, faz as ações
-- while true do
--   if findText("Play Store") then clickText("Play Store") sleep(2000) end
--   sleep(500)
-- end
"""


    private val htmlTemplate = """<!-- HTML + CSS + JS: abre numa janelinha flutuante e continua rodando em segundo plano.
     Todos os comandos (click, spam, findText, speak, ai, readScreen...) funcionam aqui dentro do <script>.
     Comandos lentos (swipe, hold, ai, post, listen, waitText...) devolvem Promise: use await. -->
<style>
  body { font-family: sans-serif; margin: 8px; background: #fff; color: #111; }
  button { padding: 12px; margin: 4px; font-size: 16px; border-radius: 8px; }
  #out { margin-top: 8px; color: #06c; }
</style>
<h3>Meu painel</h3>
<button onclick="spam(540, 1200, 20)">Spam</button>
<button onclick="stopSpam()">Parar spam</button>
<button onclick="readScreen()">Ler a tela</button>
<button onclick="perguntar()">Perguntar à IA</button>
<div id="out">pronto</div>
<script>
  async function perguntar() {
    document.getElementById("out").textContent = "pensando...";
    var r = await askScreen("Resuma o que está na tela");
    document.getElementById("out").textContent = r;
    speak(r);
  }
  onVolumeUp(function () { spam(540, 1200, 20); });
  onVolumeDown(function () { stopSpam(); });
  // Gatilho pela tela:
  // (async function () { while (true) { if (findText("Play Store")) { clickText("Play Store"); await sleep(2000); } await sleep(500); } })();
</script>
"""

    private val helpText = """COMANDOS (valem em JavaScript, Lua e HTML)

TOQUE
click(x,y)  tap(x,y)  doubleClick(x,y)
spam(x,y,ms)  stopSpam()
hold(x,y,ms)  longPress(x,y)
swipe(x1,y1,x2,y2,ms)
pinch(x,y,de,ate,ms)  (zoom com 2 dedos)
scroll("down"|"up"|"left"|"right")

NAVEGAÇÃO
back()  home()  recents()  notifications()
quickSettings()  powerMenu()  lockScreen()  screenshotKey()

TEXTO NA TELA
findText(t) -> {x,y} ou null
findAllText(t) -> lista de {x,y,text}
clickText(t)  waitText(t,ms)
screenText()  (todo o texto visível)
typeText(t)  addText(t)  clearText()  paste()
currentApp()  screenW()  screenH()

PIXELS (Android 11+)
pixel(x,y) -> "#RRGGBB"
findColor("#RRGGBB", tolerancia) -> "x,y"
screenshot("nome")  (salva nos anexos)

APPS E SISTEMA
openApp("nome ou pacote")  openUrl(url)  apps()
vibrate(ms)  toast(t)  flashlight(true/false)
battery()  getVolume()  setVolume(0-100)
getClipboard()  setClipboard(t)
date()  hour()  minute()  now()

VOZ E IA
speak(t)  stopSpeak()  readScreen()
listen(ms) -> texto falado
ai(pergunta)  askScreen(pergunta)  setAiModel(nome)
(IA usa a chave salva: sk-ant... Anthropic, sk-... OpenAI, AIza... Gemini)

MÍDIA
playAudio(arquivo ou url)  stopAudio()
showText(t,seg)  showImage(arquivo,seg)  files()

DADOS E ARQUIVOS
saveData(k,v)  loadData(k)
readFile(n)  writeFile(n,t)  deleteFile(n)
post(url,auth,json)  httpGet(url,auth)
getKey()

GATILHOS
onVolumeUp(f)  onVolumeDown(f)  onBubble(f)
(a bolinha: toque curto = gatilho onBubble, segurar = menu)

CONTROLE
sleep(ms)  log(t)  quit()

SÓ NO HTML
winShow()  winHide()  setWindow(x,y,larg,alt)  winFocus(true)
Comandos lentos devolvem Promise: use await.
Anexos (foto/som) ficam na mesma pasta: <img src="foto.png">
"""

    private fun dir(n: String) = File(filesDir, "proj/" + n.replace(Regex("[^A-Za-z0-9_-]"), "_"))

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        root.addView(TextView(this).apply { text = "Automator"; textSize = 26f })
        root.addView(Button(this).apply { text = "Conferir permissões"; setOnClickListener { checkPerms(true) } })
        root.addView(Button(this).apply { text = "Ajuda: todos os comandos"; setOnClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle("Comandos").setMessage(helpText).setPositiveButton("Fechar", null).show() } })
        val key = EditText(this).apply { hint = "Chave de API (opcional)"; setText(Store.key(this@MainActivity)); setSingleLine() }
        root.addView(key)
        root.addView(Button(this).apply { text = "Salvar chave"; setOnClickListener { Store.setKey(context, key.text.toString()); toast("Chave salva") } })
        lv = ListView(this)
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "+"; textSize = 24f; setOnClickListener { editor(-1) } })
        setContentView(root)
        lv.setOnItemClickListener { _, _, i, _ -> startScript(i) }
        lv.setOnItemLongClickListener { _, _, i, _ ->
            AlertDialog.Builder(this).setTitle(list[i].first)
                .setItems(arrayOf("Editar", "Apagar")) { _, w -> if (w == 0) editor(i) else confirmDelete(i) { refresh() } }
                .show()
            true
        }
        refresh()
    }

    /** Toque no script da lista = liga na hora. Para desligar: bolinha > "Parar e fechar". */
    private fun startScript(i: Int) {
        if (i < 0 || i >= list.size) return
        if (!checkPerms(false)) return
        val n = list[i].first
        val d = dir(n); d.mkdirs()
        startForegroundService(Intent(this, OverlayService::class.java)
            .putExtra("code", list[i].second).putExtra("dir", d.absolutePath)
            .putExtra("lang", Store.lang(this, n)))
        toast("Ligado! Para desligar: toque na bolinha azul > Parar e fechar")
        moveTaskToBack(true)
    }

    private fun refresh() {
        list = Store.scripts(this)
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list.map { it.first })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun confirmDelete(i: Int, done: () -> Unit) {
        AlertDialog.Builder(this).setMessage("Apagar \"${list[i].first}\" e todos os arquivos dele?")
            .setPositiveButton("Apagar") { _, _ ->
                dir(list[i].first).deleteRecursively(); Store.delLang(this, list[i].first)
                list.removeAt(i); Store.save(this, list); done()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun accessibilityOn() = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        .orEmpty().contains(packageName)

    private fun checkPerms(showOk: Boolean): Boolean {
        val ps = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) ps.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = ps.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        if (!Settings.canDrawOverlays(this)) {
            toast("Ative \"Exibir sobre outros apps\" para o Automator")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return false
        }
        if (!accessibilityOn()) {
            toast("Ative o Automator em Acessibilidade")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); return false
        }
        if (showOk) toast("Tudo liberado ✅"); return true
    }

    private fun editor(idx: Int) {
        val ctx = this
        var cur = idx
        val oldName = if (idx >= 0) list[idx].first else null
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 16, 32, 0) }
        val lang = Spinner(ctx).apply {
            adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, langs)
            if (idx >= 0) setSelection(langs.indexOf(Store.lang(ctx, list[idx].first)).coerceAtLeast(0))
        }
        val name = EditText(ctx).apply { hint = "Nome"; setSingleLine(); if (idx >= 0) setText(list[idx].first) }
        val code = EditText(ctx).apply {
            typeface = Typeface.MONOSPACE; textSize = 13f; minLines = 10; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(if (idx >= 0) list[idx].second else jsTemplate)
        }
        lang.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val t = code.text.toString()
                if (t.isBlank() || t == jsTemplate || t == luaTemplate || t == htmlTemplate) code.setText(when (pos) { 1 -> luaTemplate; 2 -> htmlTemplate; else -> jsTemplate })
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        fun save(): File {
            var n = name.text.toString().trim().ifBlank { "Script ${list.size + 1}" }
            val taken = list.withIndex().filter { it.index != cur }.map { it.value.first }
            var k = 2; val base = n
            while (n in taken) { n = base + "_" + k; k++ }
            if (cur >= 0) {
                val od = dir(list[cur].first); val nd = dir(n)
                if (list[cur].first != n && od.exists() && !nd.exists()) od.renameTo(nd)
                list[cur] = n to code.text.toString()
            } else { list.add(n to code.text.toString()); cur = list.lastIndex }
            Store.setLang(ctx, n, lang.selectedItem.toString())
            if (oldName != null && oldName != n) Store.delLang(ctx, oldName)
            Store.save(ctx, list); refresh()
            return dir(n)
        }
        val attach = Button(ctx).apply {
            text = "📎 Anexar som / música / vídeo / foto"; isAllCaps = false
            setOnClickListener {
                pendingDir = save()
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "video/*", "image/*"))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 7)
            }
        }
        val manage = Button(ctx).apply {
            text = "Ver / remover anexos"; isAllCaps = false
            setOnClickListener {
                val d = save(); val names = d.list()?.sorted()?.toTypedArray() ?: emptyArray()
                if (names.isEmpty()) { toast("Nenhum anexo"); return@setOnClickListener }
                AlertDialog.Builder(ctx).setTitle("Toque para remover")
                    .setItems(names) { _, i -> File(d, names[i]).delete(); toast("Removido: ${names[i]}") }
                    .setNegativeButton("Fechar", null).show()
            }
        }
        box.addView(lang); box.addView(name); box.addView(attach); box.addView(manage); box.addView(code)
        val dlg = AlertDialog.Builder(ctx).setView(ScrollView(ctx).apply { addView(box) })
            .setPositiveButton("Começar") { _, _ ->
                val d = save()
                if (checkPerms(false)) {
                    startForegroundService(Intent(ctx, OverlayService::class.java)
                        .putExtra("code", code.text.toString()).putExtra("dir", d.absolutePath)
                        .putExtra("lang", lang.selectedItem.toString()))
                    moveTaskToBack(true)
                }
            }
            .setNeutralButton("Salvar") { _, _ -> save() }
        if (idx >= 0) dlg.setNegativeButton("Apagar") { _, _ -> confirmDelete(cur) { refresh() } }
        else dlg.setNegativeButton("Cancelar", null)
        dlg.show()
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r != 7 || c != RESULT_OK || d == null) return
        val target = pendingDir ?: return
        target.mkdirs()
        val uris = LinkedHashSet<Uri>()
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        d.data?.let { uris.add(it) }
        toast("Copiando arquivos…")
        Thread {
            var n = 0
            for (u in uris) {
                try {
                    val nm = contentResolver.query(u, null, null, null, null)?.use {
                        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                    } ?: "arquivo$n"
                    contentResolver.openInputStream(u)?.use { i -> File(target, nm).outputStream().use { o -> i.copyTo(o) } }
                    n++
                } catch (_: Exception) {}
            }
            runOnUiThread { toast("$n arquivo(s) adicionado(s)") }
        }.start()
    }
}
