package com.example.rec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var btn: View
    private lateinit var root: LinearLayout

    private val fpsV = listOf(24, 30, 45, 60, 90, 120)
    private val mbpsV = listOf(4, 8, 12, 16, 24, 32, 50)
    private val qV = listOf(0, 1440, 1080, 720, 480)
    private val qL = listOf("Nativa", "1440p", "1080p", "720p", "480p")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = getSharedPreferences("cfg", MODE_PRIVATE)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.WHITE)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(24), dp(56), dp(24), dp(48))
        scroll.addView(root)

        btn = View(this)
        val lp = LinearLayout.LayoutParams(dp(120), dp(120))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.bottomMargin = dp(32)
        root.addView(btn, lp)
        btn.setOnClickListener {
            if (RecService.recording) {
                startService(Intent(this, RecService::class.java).setAction(RecService.ACTION_STOP))
            } else requestStart()
        }

        row("FPS", fpsV.map { "$it fps" }, fpsV.indexOf(p.getInt("fps", 60)).coerceAtLeast(0)) { p.edit().putInt("fps", fpsV[it]).apply() }
        row("Bitrate", mbpsV.map { "$it Mbps" }, mbpsV.indexOf(p.getInt("mbps", 16)).coerceAtLeast(0)) { p.edit().putInt("mbps", mbpsV[it]).apply() }
        row("Qualidade", qL, qV.indexOf(p.getInt("q", 1080)).coerceAtLeast(0)) { p.edit().putInt("q", qV[it]).apply() }
        row("Orientação", listOf("Horizontal", "Vertical"), if (p.getBoolean("land", true)) 0 else 1) { p.edit().putBoolean("land", it == 0).apply() }
        row("Áudio", listOf("Interno", "Externo (microfone)", "Interno + externo"), p.getInt("audio", 2)) { p.edit().putInt("audio", it).apply() }

        val sw = Switch(this)
        sw.text = "Mostrar toques"
        sw.setTextColor(Color.BLACK)
        sw.isChecked = p.getBoolean("touch", false)
        sw.setOnCheckedChangeListener { v, on ->
            if (on && !Touch.canWrite(this)) {
                v.isChecked = false
                showAdb()
            } else p.edit().putBoolean("touch", on).apply()
        }
        val sl = LinearLayout.LayoutParams(-1, -2)
        sl.topMargin = dp(24)
        root.addView(sw, sl)

        root.addView(TextView(this).apply {
            text = "Script (JavaScript)"; setTextColor(Color.BLACK); textSize = 13f; setPadding(0, dp(24), 0, 0)
        })
        val et = EditText(this)
        et.setText(p.getString("script", null) ?: Cfg.DEFAULT_SCRIPT)
        et.typeface = Typeface.MONOSPACE
        et.textSize = 12f
        et.setTextColor(Color.BLACK)
        et.gravity = Gravity.TOP
        et.minLines = 10
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { p.edit().putString("script", e.toString()).apply() }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        root.addView(et, LinearLayout.LayoutParams(-1, -2))

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render(RecService.recording)
        RecService.listener = { r -> render(r) }
    }

    override fun onPause() {
        super.onPause()
        RecService.listener = null
    }

    private fun render(rec: Boolean) {
        val g = GradientDrawable()
        g.shape = if (rec) GradientDrawable.RECTANGLE else GradientDrawable.OVAL
        g.setColor(Color.BLACK)
        btn.background = g
    }

    private fun row(label: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
        root.addView(TextView(this).apply {
            text = label; setTextColor(Color.BLACK); textSize = 13f; setPadding(0, dp(16), 0, 0)
        })
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        root.addView(sp, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showAdb() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setMessage("Para mostrar toques, rode uma vez no PC (depuração USB ligada):\n\n$cmd")
            .setPositiveButton("Copiar") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("adb", cmd))
            }
            .setNegativeButton("OK", null)
            .show()
    }

    private fun requestStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else launchProjection()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjection()
        else Toast.makeText(this, "Permita o microfone/áudio", Toast.LENGTH_SHORT).show()
    }

    private fun launchProjection() {
        val m = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(m.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 2 && res == RESULT_OK && data != null) {
            val i = Intent(this, RecService::class.java).setAction(RecService.ACTION_START)
                .putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
