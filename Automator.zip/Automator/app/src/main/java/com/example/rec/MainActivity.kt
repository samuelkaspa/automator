package com.example.rec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import rikka.shizuku.Shizuku
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private lateinit var btn: View
    private lateinit var root: LinearLayout
    private var touchSw: Switch? = null
    private val shizukuL = Shizuku.OnRequestPermissionResultListener { _, res ->
        if (res == PackageManager.PERMISSION_GRANTED) doShizukuGrant()
        else runOnUiThread { Toast.makeText(this, "Permissão do Shizuku negada", Toast.LENGTH_SHORT).show() }
    }

    private val fpsV = listOf(24, 30, 45, 60, 90, 120)
    private val mbpsV = listOf(4, 8, 12, 16, 24, 32, 50)
    private val qV = listOf(0, 1440, 1080, 720, 480)
    private val qL = listOf("Nativa", "1440p", "1080p", "720p", "480p")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        p = getSharedPreferences("cfg", MODE_PRIVATE)
        try { Shizuku.addRequestPermissionResultListener(shizukuL) } catch (e: Throwable) {}

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.WHITE)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(24), dp(56), dp(24), dp(48))
        scroll.addView(root)

        btn = View(this)
        val lp = LinearLayout.LayoutParams(dp(120), dp(120))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.bottomMargin = dp(32)
        root.addView(btn, lp)
        btn.setOnClickListener {
            if (RecService.recording) {
                startService(Intent(this, RecService::class.java).setAction(RecService.ACTION_STOP))
            } else requestStart()
        }

        row("FPS", fpsV.map { "$it fps" }, fpsV.indexOf(p.getInt("fps", 60)).coerceAtLeast(0)) { p.edit().putInt("fps", fpsV[it]).apply() }
        row("Bitrate", mbpsV.map { "$it Mbps" }, mbpsV.indexOf(p.getInt("mbps", 16)).coerceAtLeast(0)) { p.edit().putInt("mbps", mbpsV[it]).apply() }
        row("Qualidade", qL, qV.indexOf(p.getInt("q", 1080)).coerceAtLeast(0)) { p.edit().putInt("q", qV[it]).apply() }
        row("Orientação", listOf("Horizontal", "Vertical"), if (p.getBoolean("land", true)) 0 else 1) { p.edit().putBoolean("land", it == 0).apply() }
        row("Áudio", listOf("Interno", "Externo (microfone)", "Interno + externo"), p.getInt("audio", 2)) { p.edit().putInt("audio", it).apply() }

        header("Voz")
        seek("Altura da minha voz", "micPitch", -12, 12, 0) { semis(it) }
        seek("Volume da minha voz", "micVol", 0, 200, 100) { "$it%" }
        seek("Altura da voz do jogo", "gamePitch", -12, 12, 0) { semis(it) }
        seek("Volume do jogo", "gameVol", 0, 200, 100) { "$it%" }
        note("A altura muda sem alterar a velocidade. 0 = normal (sem uso extra de CPU). Pode ser ajustada durante a gravação.")

        header("Desempenho (evita travar o jogo)")
        val perfL = listOf("Personalizado", "Leve (jogo pesado / celular fraco)", "Equilibrado", "Máximo (qualidade)")
        val cur = p.getInt("perf", 0)
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, perfL)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(cur)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos == p.getInt("perf", 0)) return
                applyPreset(pos)
                recreate()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        root.addView(sp, LinearLayout.LayoutParams(-1, -2))
        sw("Modo econômico (menos CPU e calor)", "eco", true)
        sw("Taxa de bits constante (evita picos que travam)", "cbr", false)
        sw("Parar se o aparelho superaquecer", "thermal", true)
        row("Parar se a bateria baixar de", listOf("Nunca", "10%", "15%", "20%"), listOf(0, 10, 15, 20).indexOf(p.getInt("minBat", 0)).coerceAtLeast(0)) {
            p.edit().putInt("minBat", listOf(0, 10, 15, 20)[it]).apply()
        }
        note("Dica: Leve = 30 fps, 720p, 8 Mbps. Em tela de 90/120 Hz o encoder já é limitado ao FPS escolhido. Durante a gravação, a notificação mostra o uso de CPU do app.")
        val bt = Button(this)
        bt.text = "Não deixar o sistema encerrar em segundo plano"
        bt.setOnClickListener { askBatteryExemption() }
        root.addView(bt, LinearLayout.LayoutParams(-1, -2))

        header("Toques na tela")
        val sw = Switch(this)
        sw.text = "Mostrar toques"
        sw.setTextColor(Color.BLACK)
        touchSw = sw
        sw.isChecked = p.getBoolean("touch", false) && Touch.canWrite(this)
        sw.setOnCheckedChangeListener { v, on ->
            if (on && !Touch.canWrite(this)) {
                v.isChecked = false
                showAdb()
            } else p.edit().putBoolean("touch", on).apply()
        }
        val sl = LinearLayout.LayoutParams(-1, -2)
        sl.topMargin = dp(8)
        root.addView(sw, sl)
        val tb = Button(this)
        tb.text = "Ativar toques sem PC"
        tb.setOnClickListener { showAdb() }
        root.addView(tb, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "Script (JavaScript)"; setTextColor(Color.BLACK); textSize = 13f; setPadding(0, dp(24), 0, 0)
        })
        val et = EditText(this)
        et.setText(p.getString("script", null) ?: Cfg.DEFAULT_SCRIPT)
        et.typeface = Typeface.MONOSPACE
        et.textSize = 12f
        et.setTextColor(Color.BLACK)
        et.gravity = Gravity.TOP
        et.minLines = 10
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { p.edit().putString("script", e.toString()).apply() }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        root.addView(et, LinearLayout.LayoutParams(-1, -2))

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render(RecService.recording)
        RecService.listener = { r -> render(r) }
    }

    override fun onPause() {
        super.onPause()
        RecService.listener = null
    }

    private fun render(rec: Boolean) {
        val g = GradientDrawable()
        g.shape = if (rec) GradientDrawable.RECTANGLE else GradientDrawable.OVAL
        g.setColor(Color.BLACK)
        btn.background = g
    }

    private fun row(label: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
        root.addView(TextView(this).apply {
            text = label; setTextColor(Color.BLACK); textSize = 13f; setPadding(0, dp(16), 0, 0)
        })
        val sp = Spinner(this)
        val ad = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sp.adapter = ad
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        root.addView(sp, LinearLayout.LayoutParams(-1, -2))
    }

    private fun showAdb() {
        if (Touch.canWrite(this)) {
            Toast.makeText(this, "Já está liberado. Pode ligar \"Mostrar toques\".", Toast.LENGTH_LONG).show()
            return
        }
        val items = arrayOf("Conceder agora pelo Shizuku (sem PC)", "Passo a passo sem PC", "Comando para o PC")
        AlertDialog.Builder(this)
            .setTitle("Mostrar toques")
            .setItems(items) { _, w ->
                when (w) {
                    0 -> grantWithShizuku()
                    1 -> showSteps()
                    else -> showPcCmd()
                }
            }
            .show()
    }

    private fun grantWithShizuku() {
        when {
            !ShizukuHelper.installed(this) -> {
                Toast.makeText(this, "Instale o Shizuku primeiro (veja o passo a passo)", Toast.LENGTH_LONG).show()
                showSteps()
            }
            !ShizukuHelper.running() -> {
                Toast.makeText(this, "Abra o Shizuku e inicie pela Depuração sem fio", Toast.LENGTH_LONG).show()
                packageManager.getLaunchIntentForPackage(ShizukuHelper.PKG)?.let { startActivity(it) }
            }
            !ShizukuHelper.granted() -> {
                try { Shizuku.requestPermission(10) } catch (e: Throwable) {
                    Toast.makeText(this, "Falha ao pedir permissão ao Shizuku", Toast.LENGTH_SHORT).show()
                }
            }
            else -> doShizukuGrant()
        }
    }

    private fun doShizukuGrant() {
        Thread {
            val ok = ShizukuHelper.grantSelf(this)
            runOnUiThread {
                if (ok) {
                    p.edit().putBoolean("touch", true).apply()
                    touchSw?.isChecked = true
                    Toast.makeText(this, "Pronto! Toques liberados para sempre, sem PC.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, "Não consegui conceder. Confira se o Shizuku está ativo.", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun showSteps() {
        AlertDialog.Builder(this)
            .setTitle("Sem PC (uma vez só)")
            .setMessage(
                "1. Instale o Shizuku (Play Store ou shizuku.rikka.app).\n" +
                "2. Configurações > Sobre o telefone > toque 7x em \"Número da versão\".\n" +
                "3. Opções do desenvolvedor > ligue \"Depuração sem fio\" (precisa de Wi-Fi só agora).\n" +
                "4. Abra o Shizuku > \"Iniciar via depuração sem fio\" > faça o pareamento pela notificação (digite o código) > Iniciar.\n" +
                "5. Volte aqui > \"Ativar toques sem PC\" > \"Conceder agora pelo Shizuku\" e aceite.\n\n" +
                "Depois disso a permissão fica salva: os toques funcionam com a tela gravando em segundo plano, " +
                "mesmo reiniciando o celular e com Shizuku/Wi-Fi desligados (só perde se desinstalar o app)."
            )
            .setPositiveButton("Abrir Shizuku") { _, _ ->
                val i = packageManager.getLaunchIntentForPackage(ShizukuHelper.PKG)
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                startActivity(i)
            }
            .setNegativeButton("OK", null)
            .show()
    }

    private fun showPcCmd() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setMessage("Rode uma vez no PC (depuração USB ligada):\n\n$cmd")
            .setPositiveButton("Copiar") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("adb", cmd))
            }
            .setNegativeButton("OK", null)
            .show()
    }

    private fun askBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, "Já está liberado", Toast.LENGTH_SHORT).show()
        } else {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun applyPreset(n: Int) {
        val e = p.edit().putInt("perf", n)
        when (n) {
            1 -> e.putInt("fps", 30).putInt("mbps", 8).putInt("q", 720).putBoolean("eco", true).putBoolean("cbr", true).putBoolean("thermal", true)
            2 -> e.putInt("fps", 60).putInt("mbps", 16).putInt("q", 1080).putBoolean("eco", true).putBoolean("cbr", false)
            3 -> e.putInt("fps", 60).putInt("mbps", 32).putInt("q", 0).putBoolean("eco", false).putBoolean("cbr", false)
        }
        e.apply()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { Shizuku.removeRequestPermissionResultListener(shizukuL) } catch (e: Throwable) {}
    }

    private fun semis(v: Int) = if (v == 0) "normal" else (if (v > 0) "+$v" else "$v") + " semitons"

    private fun header(t: String) {
        root.addView(TextView(this).apply {
            text = t; setTextColor(Color.BLACK); textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(32), 0, 0)
        })
    }

    private fun note(t: String) {
        root.addView(TextView(this).apply {
            text = t; setTextColor(Color.DKGRAY); textSize = 11f; setPadding(0, dp(8), 0, 0)
        })
    }

    private fun sw(label: String, key: String, def: Boolean) {
        val s = Switch(this)
        s.text = label
        s.setTextColor(Color.BLACK)
        s.isChecked = p.getBoolean(key, def)
        s.setOnCheckedChangeListener { _, on -> p.edit().putBoolean(key, on).apply() }
        val l = LinearLayout.LayoutParams(-1, -2)
        l.topMargin = dp(12)
        root.addView(s, l)
    }

    private fun seek(label: String, key: String, min: Int, max: Int, def: Int, fmt: (Int) -> String) {
        val v0 = p.getInt(key, def).coerceIn(min, max)
        val tv = TextView(this).apply {
            text = "$label: ${fmt(v0)}"; setTextColor(Color.BLACK); textSize = 13f; setPadding(0, dp(16), 0, 0)
        }
        root.addView(tv)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = v0 - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, user: Boolean) {
                val v = pr + min
                tv.text = "$label: ${fmt(v)}"
                if (user) p.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb, LinearLayout.LayoutParams(-1, -2))
    }

    private fun requestStart() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else launchProjection()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchProjection()
        else Toast.makeText(this, "Permita o microfone/áudio", Toast.LENGTH_SHORT).show()
    }

    private fun launchProjection() {
        val m = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(m.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 2 && res == RESULT_OK && data != null) {
            val i = Intent(this, RecService::class.java).setAction(RecService.ACTION_START)
                .putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
