plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.automator"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.automator"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "META-INF/**" }
}
dependencies { implementation("org.mozilla:rhino:1.7.14")
    implementation("org.luaj:luaj-jse:3.0.1") }
